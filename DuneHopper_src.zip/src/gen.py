#!/usr/bin/env python3
"""Asset + table generator for DUNE HOPPER (original MSX2 game).

Produces binary blobs and include files consumed by main.asm.
All art here is original and drawn procedurally / by hand below.
"""
import math, os, random

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- geometry
HORIZON = 96
ROWS = 116            # screen rows 96..211
R0 = 4
ZK = 4096
WBOT = 112            # road half width at bottom row (px)
MAXR = 160            # rows table extended below screen for near objects

def zrow(r):
    return ZK / (r + R0)

def wrow(r):
    return round(WBOT * (r + R0) / (ROWS - 1 + R0))

def erow(r):
    return max(1, round(8 * (r + R0) / (ROWS - 1 + R0)))

def medrow(r):
    return max(0, round(5 * (r + R0) / (ROWS - 1 + R0)))

def setrow(r):
    z = zrow(r)
    return int(4 * ((z / 32.0) % 1.0)) & 3

# ---------------------------------------------------------------- palette indices
C_BLACK, C_WHITE, C_SKY, C_DARK, C_RED, C_YEL, C_BROWN, C_GREEN = 0, 9, 10, 11, 12, 13, 14, 15
def grass(s): return 1 + s
def track(s): return 5 + s

# ---------------------------------------------------------------- helpers
def rle(data):
    """control byte c: c<128 -> c+1 literals follow; c>=128 -> run of (c-127) of next byte"""
    out = bytearray()
    i, n = 0, len(data)
    lit = bytearray()
    def flush():
        nonlocal lit
        while lit:
            chunk = lit[:128]
            out.append(len(chunk) - 1)
            out.extend(chunk)
            lit = lit[128:]
    while i < n:
        j = i
        while j < n and data[j] == data[i] and j - i < 128:
            j += 1
        run = j - i
        if run >= 3:
            flush()
            out.append(0x80 + run - 1)
            out.append(data[i])
            i = j
        else:
            lit.append(data[i])
            i += 1
    flush()
    return bytes(out)

def pack4(img, w, h):
    """img: list of rows of palette indices -> screen5 bytes"""
    out = bytearray()
    for y in range(h):
        row = img[y]
        for x in range(0, w, 2):
            out.append(((row[x] & 15) << 4) | (row[x + 1] & 15))
    return bytes(out)

def newimg(w, h, c=0):
    return [[c] * w for _ in range(h)]

def wbin(name, data):
    with open(os.path.join(OUT, name), "wb") as f:
        f.write(data)

# ---------------------------------------------------------------- font (original 5x7)
FONT_ORDER = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!:-.+x/'&"
FONT = {
 ' ': ["     "]*7,
 '0': [" ### ","#   #","#  ##","# # #","##  #","#   #"," ### "],
 '1': ["  #  "," ##  ","  #  ","  #  ","  #  ","  #  "," ### "],
 '2': [" ### ","#   #","    #","  ## "," #   ","#    ","#####"],
 '3': ["#####","   # ","  #  ","   # ","    #","#   #"," ### "],
 '4': ["   # ","  ## "," # # ","#  # ","#####","   # ","   # "],
 '5': ["#####","#    ","#### ","    #","    #","#   #"," ### "],
 '6': ["  ## "," #   ","#    ","#### ","#   #","#   #"," ### "],
 '7': ["#####","    #","   # ","  #  "," #   "," #   "," #   "],
 '8': [" ### ","#   #","#   #"," ### ","#   #","#   #"," ### "],
 '9': [" ### ","#   #","#   #"," ####","    #","   # "," ##  "],
 'A': [" ### ","#   #","#   #","#####","#   #","#   #","#   #"],
 'B': ["#### ","#   #","#   #","#### ","#   #","#   #","#### "],
 'C': [" ### ","#   #","#    ","#    ","#    ","#   #"," ### "],
 'D': ["#### ","#   #","#   #","#   #","#   #","#   #","#### "],
 'E': ["#####","#    ","#    ","#### ","#    ","#    ","#####"],
 'F': ["#####","#    ","#    ","#### ","#    ","#    ","#    "],
 'G': [" ### ","#   #","#    ","# ###","#   #","#   #"," ####"],
 'H': ["#   #","#   #","#   #","#####","#   #","#   #","#   #"],
 'I': [" ### ","  #  ","  #  ","  #  ","  #  ","  #  "," ### "],
 'J': ["  ###","   # ","   # ","   # ","   # ","#  # "," ##  "],
 'K': ["#   #","#  # ","# #  ","##   ","# #  ","#  # ","#   #"],
 'L': ["#    ","#    ","#    ","#    ","#    ","#    ","#####"],
 'M': ["#   #","## ##","# # #","# # #","#   #","#   #","#   #"],
 'N': ["#   #","#   #","##  #","# # #","#  ##","#   #","#   #"],
 'O': [" ### ","#   #","#   #","#   #","#   #","#   #"," ### "],
 'P': ["#### ","#   #","#   #","#### ","#    ","#    ","#    "],
 'Q': [" ### ","#   #","#   #","#   #","# # #","#  # "," ## #"],
 'R': ["#### ","#   #","#   #","#### ","# #  ","#  # ","#   #"],
 'S': [" ####","#    ","#    "," ### ","    #","    #","#### "],
 'T': ["#####","  #  ","  #  ","  #  ","  #  ","  #  ","  #  "],
 'U': ["#   #","#   #","#   #","#   #","#   #","#   #"," ### "],
 'V': ["#   #","#   #","#   #","#   #","#   #"," # # ","  #  "],
 'W': ["#   #","#   #","#   #","# # #","# # #","# # #"," # # "],
 'X': ["#   #","#   #"," # # ","  #  "," # # ","#   #","#   #"],
 'Y': ["#   #","#   #"," # # ","  #  ","  #  ","  #  ","  #  "],
 'Z': ["#####","    #","   # ","  #  "," #   ","#    ","#####"],
 '!': ["  #  ","  #  ","  #  ","  #  ","  #  ","     ","  #  "],
 ':': ["     ","  #  ","  #  ","     ","  #  ","  #  ","     "],
 '-': ["     ","     ","     ","#####","     ","     ","     "],
 '.': ["     ","     ","     ","     ","     "," ##  "," ##  "],
 '+': ["     ","  #  ","  #  ","#####","  #  ","  #  ","     "],
 'x': ["     ","     ","#   #"," # # ","  #  "," # # ","#   #"],
 '/': ["    #","    #","   # ","  #  "," #   ","#    ","#    "],
 "'": ["  #  ","  #  "," #   ","     ","     ","     ","     "],
 '&': [" ##  ","#  # ","# #  "," #   ","# # #","#  # "," ## #"],
}
assert all(len(FONT[c]) == 7 and all(len(r) == 5 for r in FONT[c]) for c in FONT_ORDER)

# ---------------------------------------------------------------- object art (original)
def put(img, x, y, c):
    if 0 <= y < len(img) and 0 <= x < len(img[0]):
        img[y][x] = c

def ellipse(img, cx, cy, rx, ry, c):
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1.0:
                put(img, x, y, c)

def rect(img, x0, y0, x1, y1, c):
    for y in range(y0, y1):
        for x in range(x0, x1):
            put(img, x, y, c)

def art_tree():
    w, h = 28, 44
    im = newimg(w, h)
    rect(im, 12, 30, 16, 44, C_BROWN)
    rect(im, 12, 30, 13, 44, C_DARK)
    # layered round canopy
    for (cx, cy, rx, ry) in [(14, 25, 13, 8), (14, 17, 11, 8), (14, 9, 8, 7), (14, 3.5, 4, 3.5)]:
        ellipse(im, cx, cy, rx, ry, C_GREEN)
    # shading: dark on the right-bottom edges
    for y in range(h):
        for x in range(w):
            if im[y][x] == C_GREEN:
                if x + 1 < w and im[y][x + 1] == 0 or (y + 1 < h and im[y + 1][x] == 0 and x > 14):
                    im[y][x] = C_DARK
    # a few highlight dots
    for (x, y) in [(8, 22), (9, 23), (10, 14), (11, 15), (12, 7), (6, 25), (7, 26)]:
        if im[y][x] == C_GREEN:
            im[y][x] = C_YEL
    return im

def art_rock():
    w, h = 28, 16
    im = newimg(w, h)
    ellipse(im, 14, 10, 13.5, 8, C_DARK)
    ellipse(im, 11, 7, 7, 4.5, C_WHITE)
    ellipse(im, 12.5, 8.5, 7, 4, C_DARK)
    for (x, y) in [(6, 6), (7, 5), (8, 5), (18, 7), (19, 7)]:
        put(im, x, y, C_WHITE)
    return im

def art_log():
    w, h = 64, 14
    im = newimg(w, h)
    rect(im, 6, 1, 58, 13, C_BROWN)
    for x in range(6, 58):
        put(im, x, 1, C_DARK); put(im, x, 12, C_DARK)
        if x % 9 == 3:
            for y in range(4, 10):
                put(im, x, y, C_DARK)
    ellipse(im, 58, 7, 5.5, 6.5, C_DARK)
    ellipse(im, 58, 7, 4.5, 5.5, C_YEL)
    ellipse(im, 58, 7, 2, 2.5, C_BROWN)
    ellipse(im, 6, 7, 5.5, 6.5, C_DARK)
    ellipse(im, 6, 7, 4.5, 5.5, C_YEL)
    ellipse(im, 6, 7, 2, 2.5, C_BROWN)
    return im

def art_star():
    w, h = 20, 20
    im = newimg(w, h)
    cx, cy = 9.5, 10
    for y in range(h):
        for x in range(w):
            dx, dy = x + .5 - cx, y + .5 - cy
            a = math.atan2(dy, dx) + math.pi / 2
            rr = math.hypot(dx, dy)
            k = (math.cos(5 * a) + 1) / 2
            lim = 4 + 5.5 * k
            if rr <= lim + 0.6:
                im[y][x] = C_RED
            if rr <= lim - 0.6:
                im[y][x] = C_YEL
            if rr <= 2.2:
                im[y][x] = C_WHITE
    return im

def art_post():
    w, h = 8, 52
    im = newimg(w, h)
    for y in range(h):
        c = C_RED if (y // 6) % 2 == 0 else C_WHITE
        for x in range(1, 7):
            im[y][x] = c
        im[y][6] = C_DARK
    rect(im, 0, 0, 8, 3, C_YEL)
    return im

def art_bush():
    w, h = 24, 12
    im = newimg(w, h)
    for (cx, cy, rx, ry) in [(6, 8, 6, 4), (12, 6, 7, 6), (18, 8, 6, 4)]:
        ellipse(im, cx, cy, rx, ry, C_GREEN)
    for y in range(h):
        for x in range(w):
            if im[y][x] == C_GREEN and (y == h - 1 or (x + 1 < w and im[y][x + 1] == 0)):
                im[y][x] = C_DARK
    for (x, y) in [(10, 3), (11, 2), (5, 6), (16, 6)]:
        put(im, x, y, C_YEL)
    return im

def art_sign(right):
    w, h = 24, 28
    im = newimg(w, h)
    rect(im, 11, 14, 13, 28, C_DARK)
    rect(im, 0, 0, 24, 15, C_DARK)
    rect(im, 1, 1, 23, 14, C_YEL)
    # chevrons
    for k in range(3):
        bx = 4 + k * 6
        for y in range(2, 13):
            off = abs(y - 7)
            for t in range(2):
                x = bx + (3 - off // 2) + t if right else bx + off // 2 + t
                put(im, x, y, C_RED)
    return im

def art_shadow():
    im = newimg(40, 8)
    ellipse(im, 20, 4, 19.5, 3.8, C_DARK)
    return im

def scale_img(im, f):
    h, w = len(im), len(im[0])
    nw, nh = max(1, round(w * f)), max(1, round(h * f))
    out = newimg(nw, nh)
    for y in range(nh):
        sy = min(h - 1, int((y + 0.5) * h / nh))
        for x in range(nw):
            sx = min(w - 1, int((x + 0.5) * w / nw))
            out[y][x] = im[sy][sx]
    return out

OBJ_TYPES = [  # order = type ids used in asm
    ("TREE", art_tree()),
    ("ROCK", art_rock()),
    ("LOG", art_log()),
    ("STAR", art_star()),
    ("POST", art_post()),
    ("BUSH", art_bush()),
    ("SIGNL", art_sign(False)),
    ("SIGNR", art_sign(True)),
    ("SHADOW", art_shadow()),
]
NSCALE = 8
SCALES = [0.75 ** k for k in range(NSCALE)]

SHEET_Y0 = 116     # page 2 line where sheet starts
SHEET_H = 124      # lines available for objects
FONT_Y = 240       # page 2 line for font (2 rows of 32 glyphs)

def build_sheet():
    sheet = newimg(256, 140)
    entries = {}
    # shelf packing, tallest first
    items = []
    for t, (name, im) in enumerate(OBJ_TYPES):
        frames = [scale_img(im, s) for s in SCALES]
        items.append((len(im), t, name, frames))
    items.sort(key=lambda a: -a[0])
    shelves = []  # [y, h, used_x]
    for (hh, t, name, frames) in items:
        totw = sum(len(f[0]) + 1 for f in frames)
        for sh in shelves:
            if sh[2] + totw <= 256 and hh <= sh[1]:
                break
        else:
            y = (shelves[-1][0] + shelves[-1][1] + 1) if shelves else 0
            sh = [y, hh, 0]
            shelves.append(sh)
        shelf_y, x = sh[0], sh[2]
        sh[2] += totw
        info = []
        for f in frames:
            fw, fh = len(f[0]), len(f)
            for yy in range(fh):
                for xx in range(fw):
                    sheet[shelf_y + yy][x + xx] = f[yy][xx]
            info.append((x, shelf_y, fw, fh))
            x += fw + 1
        entries[t] = info
    used = shelves[-1][0] + shelves[-1][1]
    print("sheet lines used", used)
    assert used <= SHEET_H, ("sheet overflow", used)
    # font in last 16 lines (y 124..139 of the sheet)
    fy0 = FONT_Y - SHEET_Y0
    for i, ch in enumerate(FONT_ORDER):
        gx, gy = (i % 32) * 8, fy0 + (i // 32) * 8
        for y in range(8):
            for x in range(8):
                sheet[gy + y][gx + x] = 0
        for y, row in enumerate(FONT[ch]):
            for x, c in enumerate(row):
                if c == '#':
                    sheet[gy + y][gx + 1 + x] = C_WHITE
    return sheet, entries

# ---------------------------------------------------------------- sky (original)
BAND_Y = 58   # first screen line of the horizontally scrolling backdrop band
BAND_H = 96 - BAND_Y

def build_sky(seed=7):
    rnd = random.Random(seed)
    H = 72  # screen lines 24..95
    im = newimg(256, H, C_SKY)
    by = BAND_Y - 24
    # dithered haze near horizon (inside the band only)
    for y in range(by, H):
        for x in range(256):
            t = (y - by) / (H - by)
            if t > 0.25 and ((x + y) % 2 == 0) and rnd.random() < (t - 0.25) * 0.9:
                im[y][x] = C_WHITE
    # clouds stay above the band (static)
    for (cx, cy, sc) in [(40, 10, 1.0), (150, 6, 0.8), (215, 15, 1.1), (95, 19, 0.6)]:
        for (ox, oy, rx, ry) in [(0, 0, 14, 4), (-9, 2, 9, 3), (10, 2, 10, 3), (3, -3, 7, 3)]:
            ellipse(im, cx + ox * sc, cy + oy * sc, rx * sc, ry * sc, C_WHITE)
    for y in range(by, H):
        for x in range(256):
            if im[y][x] == C_WHITE and y < by + 2:
                im[y][x] = C_SKY
    # periodic mountain ridge (sum of integer-frequency sines => wraps at 256)
    comps = [(1, 6.0), (2, 4.0), (3, 5.0), (5, 2.5), (7, 1.6), (11, 1.0), (17, 0.6)]
    ph = [rnd.uniform(0, 2 * math.pi) for _ in comps]
    peaks = []
    for x in range(256):
        v = 20 + sum(a * math.sin(2 * math.pi * f * x / 256 + p) for (f, a), p in zip(comps, ph))
        peaks.append(max(8, min(BAND_H - 3, v)))
    for x in range(256):
        top = H - int(peaks[x])
        for y in range(top, H):
            im[y][x] = C_DARK
            if y - top < 2 and peaks[x] > 27:
                im[y][x] = C_WHITE
    # near hills
    for x in range(256):
        hh = 7 + 3 * math.sin(x / 256 * 2 * math.pi * 5) + 2 * math.sin(x / 256 * 2 * math.pi * 13 + 2)
        for y in range(H - int(hh), H):
            im[y][x] = C_GREEN
    return im

# ---------------------------------------------------------------- road source rows (page 2 lines 0..115)
def build_road():
    im = newimg(256, ROWS)
    for r in range(ROWS):
        s = setrow(r)
        w, e, m = wrow(r), erow(r), medrow(r)
        for x in range(256):
            d = abs(x + 0.5 - 128)
            if d < m:
                c = grass(s)
            elif d < w:
                c = track(s)
            elif d < w + e:
                c = C_WHITE
            else:
                c = grass(s)
            im[r][x] = c
    return im

# ---------------------------------------------------------------- title band (over sky)
def build_title(sky):
    Y0, H = 30, 58     # screen lines 30..87
    im = [row[:] for row in sky[Y0 - 24:Y0 - 24 + H]]
    text = "DUNE HOPPER"
    sc = 3
    tw = len(text) * 6 * sc
    x0 = (256 - tw) // 2 + 2
    mask = newimg(256, H)
    for i, ch in enumerate(text):
        for y, row in enumerate(FONT[ch]):
            for x, c in enumerate(row):
                if c == '#':
                    for yy in range(sc):
                        for xx in range(sc):
                            # slight italic slant
                            px = x0 + i * 6 * sc + x * sc + xx + (6 - y)
                            py = 6 + y * (sc + 1) + yy
                            if 0 <= px < 256 and 0 <= py < H:
                                mask[py][px] = 1
                            if yy == sc - 1 and 0 <= py + 1 < H and 0 <= px < 256:
                                mask[py + 1][px] = 1
    # subtitle (1x font, white with black outline)
    sub = "BY JZZY & CLAUDE - 2026"
    sx0 = (256 - len(sub) * 6) // 2
    smask = newimg(256, H)
    for i, ch in enumerate(sub):
        for y, row in enumerate(FONT[ch]):
            for x, c in enumerate(row):
                if c == '#':
                    smask[47 + y][sx0 + i * 6 + x] = 1
    for y in range(H):
        for x in range(256):
            if smask[y][x]:
                continue
            if any(0 <= y + dy < H and 0 <= x + dx < 256 and smask[y + dy][x + dx]
                   for dy in (-1, 0, 1) for dx in (-1, 0, 1)):
                im[y][x] = C_BLACK
    for y in range(H):
        for x in range(256):
            if smask[y][x]:
                im[y][x] = C_WHITE
    # logo outline + gradient fill
    for y in range(H):
        for x in range(256):
            if mask[y][x]:
                im[y][x] = C_YEL if y < 14 else (C_RED if y >= 24 else (C_YEL if (x + y) % 2 else C_RED))
            else:
                near = any(0 <= y + dy < H and 0 <= x + dx < 256 and mask[y + dy][x + dx]
                           for dy in (-1, 0, 1, 2) for dx in (-1, 0, 1, 2))
                if near:
                    im[y][x] = C_BLACK
    return Y0, H, im

# ---------------------------------------------------------------- sprites: buggy (original design)
# 32x24, '.' transparent, W white, R red, Y yellow, D dark, B brown
BUGGY = [
 "................................",
 "........WWWWWWWWWWWWWWWW........",
 ".......WW..............WW.......",
 ".......W.......RR.......W.......",
 ".......W.....RRRRRR.....W.......",
 ".......W....RRRRRRRR....W.......",
 ".......W....RWWWWWWR....W.......",
 ".......W....RRRRRRRR....W.......",
 "......WW.....RRRRRR.....WW......",
 "......W....YYYYYYYYYY....W......",
 "...YYYYYYYYYYYYYYYYYYYYYYYYYY...",
 "..YYYYYYYYYYYYYYYYYYYYYYYYYYYY..",
 "DDDDDDYYYYYYYYYYYYYYYYYYYYDDDDDD",
 "DDDDDDDRRRRRRRRRRRRRRRRRRDDDDDDD",
 "DDDDDDDRRRRRRRRRRRRRRRRRRDDDDDDD",
 "DDDDDDDYYYYYYYYYYYYYYYYYYDDDDDDD",
 "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
 "DDWDDWDDDDDDD........DDDDWDDWDDD",
 "DDDDDDDD..............DDDDDDDDDD",
 "DWDDWDDD..............DDDWDDWDDD",
 "DDDDDDDD..............DDDDDDDDDD",
 ".DDDDDD................DDDDDDD..",
 "................................",
 "................................",
]
CMAP = {'W': C_WHITE, 'R': C_RED, 'Y': C_YEL, 'D': C_DARK, 'B': C_BROWN}

def shift_rows(rows, n, upto):
    out = []
    for i, r in enumerate(rows):
        if i < upto:
            if n > 0:
                r = "." * n + r[:-n]
            elif n < 0:
                r = r[-n:] + "." * (-n)
        out.append(r)
    return out

def build_sprites():
    frames = [BUGGY, shift_rows(BUGGY, -2, 10), shift_rows(BUGGY, 2, 10)]
    pats = bytearray()
    cols = bytearray()
    for fr in frames:
        assert len(fr) == 24 and all(len(r) == 32 for r in fr)
        rows = fr + ["." * 32] * 8
        # per 16x16 quadrant (TL, TR, BL, BR), two layers
        layerA = {q: [[0] * 16 for _ in range(16)] for q in range(4)}
        layerB = {q: [[0] * 16 for _ in range(16)] for q in range(4)}
        colA = {q: [0] * 16 for q in range(4)}
        colB = {q: [0] * 16 for q in range(4)}
        for q in range(4):
            ox, oy = (q & 1) * 16, (q >> 1) * 16
            for y in range(16):
                seg = rows[oy + y][ox:ox + 16]
                cs = []
                for ch in seg:
                    if ch != '.' and CMAP[ch] not in cs:
                        cs.append(CMAP[ch])
                assert len(cs) <= 2, ("too many colors", q, y, seg)
                if cs:
                    colA[q][y] = cs[0]
                if len(cs) > 1:
                    colB[q][y] = cs[1]
                for x, ch in enumerate(seg):
                    if ch == '.':
                        continue
                    c = CMAP[ch]
                    if c == cs[0]:
                        layerA[q][y][x] = 1
                    else:
                        layerB[q][y][x] = 1
        def pat16(m):
            b = bytearray()
            for half in range(2):
                for y in range(16):
                    v = 0
                    for x in range(8):
                        v = (v << 1) | m[y][half * 8 + x]
                    b.append(v)
            return b
        for q in range(4):
            pats += pat16(layerA[q])
        for q in range(4):
            pats += pat16(layerB[q])
        for q in range(4):
            cols += bytes(colA[q])
        for q in range(4):
            cols += bytes(colB[q])
    # shadow: two 16x16 patterns (left/right halves of a 32x6 ellipse)
    sh = [[0] * 32 for _ in range(16)]
    for y in range(6):
        for x in range(32):
            if ((x + .5 - 16) / 15.5) ** 2 + ((y + .5 - 3) / 3) ** 2 <= 1:
                sh[y][x] = 1
    for half in range(2):
        m = [row[half * 16:(half + 1) * 16] for row in sh]
        b = bytearray()
        for hh in range(2):
            for y in range(16):
                v = 0
                for x in range(8):
                    v = (v << 1) | m[y][hh * 8 + x]
                b.append(v)
        pats += b
    shcol = bytes([C_BLACK if False else C_DARK] * 16)
    return bytes(pats), bytes(cols), shcol


# ---------------------------------------------------------------- falling sky objects (original, generic)
DW, DH = 64, 44

def poly(img, pts, c):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    n = len(pts)
    for y in range(int(min(ys)), int(max(ys)) + 1):
        for x in range(int(min(xs)), int(max(xs)) + 1):
            px, py = x + .5, y + .5
            inside = False
            j = n - 1
            for i in range(n):
                xi, yi = pts[i]; xj, yj = pts[j]
                if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                    inside = not inside
                j = i
            if inside:
                put(img, x, y, c)

def thick_line(img, x0, y0, x1, y1, w, c):
    n = int(max(abs(x1 - x0), abs(y1 - y0))) * 2 + 1
    for i in range(n + 1):
        t = i / n
        ellipse(img, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, w / 2, w / 2, c)

def outline(img, c=C_DARK):
    h, w = len(img), len(img[0])
    src = [row[:] for row in img]
    for y in range(h):
        for x in range(w):
            if src[y][x] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < w and 0 <= yy < h and src[yy][xx] not in (0, c):
                        img[y][x] = c
                        break

def d_ufo():
    im = newimg(DW, DH)
    ellipse(im, 32, 30, 14, 4, C_YEL)
    ellipse(im, 32, 23, 31, 7.5, C_DARK)
    ellipse(im, 32, 21, 27, 4.5, C_WHITE)
    ellipse(im, 32, 15, 13, 11, C_WHITE)
    rect(im, 5, 22, 59, 30, 0) if False else None
    ellipse(im, 32, 23, 31, 7.5, C_DARK) if False else None
    for y in range(DH):
        for x in range(DW):
            if y > 21 and im[y][x] == C_WHITE:
                im[y][x] = C_DARK
    ellipse(im, 27, 11, 4, 3, C_YEL)
    for x in (9, 18, 27, 37, 46, 55):
        ellipse(im, x, 24, 2, 1.6, C_YEL)
    for x in (13, 32, 51):
        ellipse(im, x, 25, 1.5, 1.2, C_RED)
    outline(im)
    return im

def d_rocket():
    im = newimg(DW, DH)
    # flame on top (falling nose-down)
    poly(im, [(25, 10), (39, 10), (32, 0)], C_RED)
    poly(im, [(28, 10), (36, 10), (32, 3)], C_YEL)
    rect(im, 24, 10, 40, 34, C_WHITE)
    rect(im, 24, 10, 27, 34, C_DARK)
    poly(im, [(24, 34), (40, 34), (32, 44)], C_RED)
    poly(im, [(24, 10), (24, 20), (15, 23), (15, 13)], C_RED)
    poly(im, [(40, 10), (40, 20), (49, 23), (49, 13)], C_RED)
    ellipse(im, 32, 22, 4, 4, C_DARK)
    ellipse(im, 32, 22, 2.4, 2.4, C_YEL)
    rect(im, 24, 29, 40, 31, C_RED)
    outline(im)
    return im

def d_meteor():
    im = newimg(DW, DH)
    for k in range(18):
        t = k / 17
        cx, cy = 62 - 26 * t, 1 + 30 * t
        ellipse(im, cx, cy, 2 + 7 * t, 2 + 7 * t, C_RED)
    for k in range(18):
        t = k / 17
        cx, cy = 62 - 26 * t, 1 + 30 * t
        ellipse(im, cx, cy, 1 + 4 * t, 1 + 4 * t, C_YEL)
    ellipse(im, 32, 33, 11, 10, C_BROWN)
    for (x, y, r) in [(28, 31, 2.5), (36, 37, 2), (34, 28, 1.5), (26, 38, 1.5)]:
        ellipse(im, x, y, r, r, C_DARK)
    outline(im)
    return im

def d_plane():
    im = newimg(DW, DH)
    # diving jumbo: nose bottom-right
    poly(im, [(18, 12), (40, 22), (46, 30), (12, 16)], C_WHITE)      # far wing
    thick_line(im, 6, 6, 54, 38, 10, C_WHITE)                       # fuselage
    ellipse(im, 56, 39, 5, 4, C_WHITE)
    poly(im, [(28, 26), (20, 42), (26, 42), (40, 28)], C_WHITE)      # near wing
    poly(im, [(2, 0), (10, 0), (14, 9), (6, 9)], C_RED)              # tail fin
    for i in range(7):
        put(im, 18 + i * 5, 12 + int(i * 3.3), C_DARK)
        put(im, 19 + i * 5, 12 + int(i * 3.3), C_DARK)
    ellipse(im, 55, 36, 2, 1.5, C_DARK)                               # cockpit
    thick_line(im, 8, 9, 52, 41, 1.2, C_RED)                          # cheat line
    ellipse(im, 33, 33, 3, 2, C_DARK)                                 # engine
    outline(im)
    return im

def d_dragon():
    im = newimg(DW, DH)
    # wings
    poly(im, [(30, 14), (2, 2), (8, 12), (2, 18), (12, 20), (6, 28), (28, 24)], C_GREEN)
    poly(im, [(34, 14), (62, 2), (56, 12), (62, 18), (52, 20), (58, 28), (36, 24)], C_GREEN)
    for (a, b) in [((28, 16), (6, 6)), ((28, 20), (8, 18)), ((36, 16), (58, 6)), ((36, 20), (56, 18))]:
        thick_line(im, a[0], a[1], b[0], b[1], 1, C_DARK)
    # tail curling up
    thick_line(im, 32, 14, 30, 4, 4, C_GREEN)
    thick_line(im, 30, 4, 36, 0, 3, C_GREEN)
    poly(im, [(36, 0), (41, 0), (38, 4)], C_RED)
    # body + head (diving)
    ellipse(im, 32, 24, 7, 11, C_GREEN)
    ellipse(im, 32, 26, 3.5, 8, C_YEL)
    ellipse(im, 32, 38, 5.5, 5, C_GREEN)
    poly(im, [(29, 40), (35, 40), (32, 44)], C_GREEN)
    put(im, 30, 38, C_RED); put(im, 34, 38, C_RED)
    poly(im, [(27, 34), (25, 30), (29, 33)], C_YEL)
    poly(im, [(37, 34), (39, 30), (35, 33)], C_YEL)
    outline(im)
    return im

def d_satellite():
    im = newimg(DW, DH)
    for (x0, x1) in [(1, 23), (41, 63)]:
        rect(im, x0, 15, x1, 27, C_DARK)
        for x in range(x0 + 1, x1, 4):
            rect(im, x, 16, x + 3, 26, C_YEL)
        rect(im, x0, 21, x1, 22, C_DARK)
    rect(im, 22, 20, 42, 22, C_WHITE)
    rect(im, 25, 10, 39, 30, C_YEL)
    for y in range(11, 30, 4):
        rect(im, 25, y, 39, y + 1, C_BROWN)
    rect(im, 30, 30, 34, 34, C_WHITE)
    ellipse(im, 32, 38, 9, 4, C_WHITE)
    ellipse(im, 32, 37, 6, 2, C_DARK)
    thick_line(im, 32, 10, 32, 2, 1, C_WHITE)
    ellipse(im, 32, 2, 1.5, 1.5, C_RED)
    outline(im)
    return im

def d_ecar():
    im = newimg(DW, DH)
    # generic sleek electric hatchback, side view, no branding
    poly(im, [(2, 28), (6, 22), (20, 18), (30, 10), (46, 10), (56, 18), (62, 21), (62, 31), (2, 32)], C_RED)
    poly(im, [(23, 18), (31, 12), (38, 12), (38, 18)], C_DARK)
    poly(im, [(41, 12), (46, 12), (53, 18), (41, 18)], C_DARK)
    rect(im, 4, 25, 62, 26, C_WHITE) if False else None
    rect(im, 6, 26, 60, 27, C_BROWN)
    for cx in (15, 50):
        ellipse(im, cx, 32, 7, 7, C_DARK)
        ellipse(im, cx, 32, 3.5, 3.5, C_WHITE)
        ellipse(im, cx, 32, 1.2, 1.2, C_DARK)
    rect(im, 58, 22, 62, 24, C_YEL)
    rect(im, 2, 24, 5, 26, C_WHITE)
    outline(im)
    return im

def d_phone():
    im = newimg(DW, DH)
    # giant generic smartphone
    rect(im, 18, 1, 46, 44, C_DARK)
    for (x, y) in [(18, 1), (45, 1), (18, 43), (45, 43)]:
        put(im, x, y, 0)
    rect(im, 20, 5, 44, 38, C_WHITE)
    cols = [C_RED, C_YEL, C_GREEN, C_BROWN, C_YEL, C_RED, C_BROWN, C_GREEN]
    k = 0
    for gy in range(4):
        for gx in range(4):
            if gy == 3 and gx > 1:
                continue
            x0, y0 = 22 + gx * 6, 7 + gy * 7
            rect(im, x0, y0, x0 + 4, y0 + 4, cols[k % len(cols)])
            k += 1
    rect(im, 22, 33, 42, 36, C_YEL)
    rect(im, 29, 2, 35, 3, C_WHITE)
    ellipse(im, 32, 41, 1.8, 1.5, C_WHITE)
    outline(im)
    return im

def d_computer():
    im = newimg(DW, DH)
    # generic 1980s keyboard computer, front-top view, no logo
    poly(im, [(6, 14), (58, 14), (63, 38), (1, 38)], C_DARK)
    rect(im, 1, 38, 63, 42, C_DARK)
    for row in range(4):
        y = 17 + row * 5
        inset = 7 - row
        n = 13
        span = (58 - inset) - (6 + inset)
        for i in range(n):
            x = 6 + inset + 1 + i * span // n
            rect(im, x, y, x + 3, y + 3, C_YEL if row == 0 else C_WHITE)
    rect(im, 16, 37, 46, 40, C_WHITE)
    rect(im, 56, 39, 59, 41, C_RED)
    rect(im, 4, 39, 14, 40, C_BROWN)
    outline(im)
    return im

def d_piano():
    im = newimg(DW, DH)
    # grand piano, side view, lid open
    poly(im, [(4, 20), (40, 20), (52, 16), (62, 20), (62, 30), (4, 30)], C_DARK)
    poly(im, [(8, 19), (48, 2), (52, 5), (14, 20)], C_DARK)
    thick_line(im, 30, 20, 34, 9, 1, C_WHITE)
    rect(im, 4, 26, 24, 30, C_WHITE)
    for x in range(5, 24, 3):
        rect(im, x, 26, x + 1, 28, C_DARK)
    for x in (8, 56):
        rect(im, x, 30, x + 3, 42, C_DARK)
        rect(im, x - 1, 42, x + 4, 44, C_YEL)
    rect(im, 31, 30, 34, 42, C_DARK)
    rect(im, 30, 42, 35, 44, C_YEL)
    rect(im, 40, 22, 60, 23, C_BROWN)
    outline(im, C_BROWN)
    return im

DROPS = [("UFO", d_ufo), ("ROCKET", d_rocket), ("METEOR", d_meteor), ("PLANE", d_plane),
         ("DRAGON", d_dragon), ("SATELLITE", d_satellite), ("ECAR", d_ecar), ("PHONE", d_phone),
         ("COMPUTER", d_computer), ("PIANO", d_piano)]
DROP_SLOT_Y = 212   # page 3 line

def build_drops():
    sheets = []
    info = None
    previews = []
    for name, fn in DROPS:
        base = fn()
        sh = newimg(256, DH)
        x = 0
        inf = []
        for sc in SCALES:
            f = scale_img(base, sc)
            fw, fh = len(f[0]), len(f)
            for yy in range(fh):
                for xx in range(fw):
                    sh[yy][x + xx] = f[yy][xx]
            inf.append((x, DROP_SLOT_Y, fw, fh))
            x += fw + 1
        assert x <= 257, x
        info = inf
        sheets.append(pack4(sh, 256, DH))
        previews.append(sh)
    return sheets, info, previews

# ---------------------------------------------------------------- tables
def build_tables():
    t = {}
    # F table: 32 distances x ROWS rows
    C1 = 50.0 / 1024.0
    f = bytearray()
    for q in range(32):
        zc = q * 32
        for r in range(ROWS):
            z = zrow(r)
            v = C1 * max(0.0, z - zc) ** 2 / z
            f.append(min(63, int(round(v))))
    t["ftab"] = bytes(f)
    # rowOfD: index = d>>2 (d < 1024)
    rod = bytearray()
    for i in range(256):
        d = i * 4 + 2
        r = round(ZK / d - R0)
        if r > MAXR - 1 or r < 6 or d > 820:
            rod.append(255)
        else:
            rod.append(r)
    t["rowofd"] = bytes(rod)
    rod2 = bytearray()
    for i in range(256):
        d = i * 4 + 2
        r = round(ZK / d - R0)
        rod2.append(255 if r > MAXR - 1 else max(0, r))
    t["rowofd2"] = bytes(rod2)
    t["wtab"] = bytes(min(255, wrow(r)) for r in range(MAXR))
    t["ext"] = bytes(wrow(r) + erow(r) for r in range(ROWS))
    t["grassb"] = bytes(grass(setrow(r)) * 17 for r in range(ROWS))
    sc = bytearray()
    for r in range(MAXR):
        ratio = wrow(r) / WBOT
        k = int(round(math.log(max(ratio, 1e-3)) / math.log(0.75))) if ratio < 1 else 0
        sc.append(max(0, min(NSCALE - 1, k)))
    t["scale"] = bytes(sc)
    return t

# ---------------------------------------------------------------- courses (original layouts)
T_TREE, T_ROCK, T_LOG, T_STAR, T_POST, T_BUSH, T_SIGNL, T_SIGNR = range(8)
T_GATE, T_FINISH = 8, 9

def pal(r, g, b):
    return bytes([(r << 4) | b, g])

COURSES = [
    dict(name="MEADOW", seed=11, stages=4, stage_len=5200, curv=[-2, -1, 0, 0, 1, 2],
         rocks=1300, logs=1500, grassL=(2, 6, 1), grassD=(1, 5, 0), trackL=(6, 4, 2), trackD=(5, 3, 1),
         sky=(3, 5, 7), dark=(2, 2, 4), green=(1, 4, 1)),
    dict(name="DESERT", seed=23, stages=4, stage_len=5600, curv=[-3, -2, -1, 0, 1, 2, 3],
         rocks=850, logs=1200, grassL=(7, 6, 3), grassD=(6, 5, 2), trackL=(5, 3, 2), trackD=(4, 2, 1),
         sky=(6, 6, 7), dark=(4, 2, 3), green=(3, 4, 1)),
    dict(name="TUNDRA", seed=37, stages=5, stage_len=5200, curv=[-3, -2, -1, 0, 1, 2, 3],
         rocks=650, logs=950, grassL=(7, 7, 7), grassD=(5, 5, 6), trackL=(3, 3, 4), trackD=(2, 2, 3),
         sky=(2, 3, 6), dark=(1, 1, 3), green=(0, 3, 2)),
]

def build_course(cd):
    rnd = random.Random(cd["seed"])
    total = cd["stages"] * cd["stage_len"]
    # segments
    segs = []
    z = 0
    segs.append((0, 0))
    z = 600
    while z < total + 2000:
        c = rnd.choice(cd["curv"])
        ln = rnd.randrange(400, 1200, 32)
        segs.append((z, c))
        z += ln
    # keep the start straight and the finish area straight
    segs = [(s, c) for (s, c) in segs]
    objs = []
    gates = [cd["stage_len"] * (i + 1) for i in range(cd["stages"])]
    def near_gate(zz, m=250):
        return any(abs(zz - g) < m for g in gates)
    def curv_at(zz):
        c = 0
        for (s, cc) in segs:
            if s <= zz:
                c = cc
        return c
    # trees & bushes
    for side in (-1, 1):
        zz = 120 + (side > 0) * 70
        while zz < total + 1200:
            if not near_gate(zz, 60):
                if rnd.random() < 0.8:
                    objs.append((zz, T_TREE, side * rnd.randint(88, 112)))
                else:
                    objs.append((zz, T_BUSH, side * rnd.randint(74, 86)))
            zz += rnd.randint(110, 220)
    # curve warning signs (outside of curve)
    for i, (s, c) in enumerate(segs):
        if abs(c) >= 2 and s > 400:
            for k in (330, 230, 130):
                zz = s - k
                if not near_gate(zz, 80):
                    side = -1 if c > 0 else 1
                    objs.append((zz, T_SIGNR if c > 0 else T_SIGNL, side * 80))
    # track hazards and pickups
    occupied = []
    def free(zz, m=160):
        return all(abs(zz - o) > m for o in occupied) and not near_gate(zz, 300)
    zz = 1200
    while zz < total - 200:
        zz += rnd.randint(cd["rocks"] // 2, cd["rocks"])
        if free(zz):
            objs.append((zz, T_ROCK, rnd.randint(-46, 46))); occupied.append(zz)
    zz = 1600
    while zz < total - 200:
        zz += rnd.randint(cd["logs"] // 2, cd["logs"])
        if free(zz):
            objs.append((zz, T_LOG, rnd.randint(-26, 26))); occupied.append(zz)
    zz = 900
    while zz < total - 200:
        zz += rnd.randint(500, 1100)
        if free(zz, 140):
            x = rnd.randint(-40, 40)
            for k in range(3):
                objs.append((zz + k * 45, T_STAR, x)); occupied.append(zz + k * 45)
    for i, g in enumerate(gates):
        objs.append((g, T_FINISH if i == len(gates) - 1 else T_GATE, 0))
    # roadside trees must not stand on the road in curves: fine (x is lateral to road)
    objs.sort(key=lambda o: o[0])
    seg_b = bytearray()
    for (s, c) in segs:
        seg_b += bytes([s & 255, s >> 8, c & 255])
    seg_b += bytes([255, 255, 0])
    obj_b = bytearray()
    for (zz, t, x) in objs:
        assert 0 < zz < 65000
        obj_b += bytes([zz & 255, zz >> 8, t, x & 255])
    obj_b += bytes([255, 255, 255, 0])
    pal_b = bytearray()
    pal_b += pal(0, 0, 0)
    for i in range(4):
        pal_b += pal(*cd["grassL"])
    for i in range(4):
        pal_b += pal(*cd["trackL"])
    pal_b += pal(7, 7, 7) + pal(*cd["sky"]) + pal(*cd["dark"]) + pal(7, 1, 1) + pal(7, 6, 1) + pal(4, 2, 1) + pal(*cd["green"])
    light_dark = pal(*cd["grassL"]) + pal(*cd["grassD"]) + pal(*cd["trackL"]) + pal(*cd["trackD"])
    return seg_b, obj_b, bytes(pal_b), light_dark, len(objs)

# ---------------------------------------------------------------- main
def main():
    sheet, entries = build_sheet()
    sky = build_sky()
    road = build_road()
    ty0, th, title = build_title(sky)
    wbin("road.rle", rle(pack4(road, 256, ROWS)))
    wbin("sky.rle", rle(pack4(sky, 256, 72)))
    wbin("sheet.rle", rle(pack4(sheet, 256, 140)))
    wbin("title.rle", rle(pack4(title, 256, th)))
    pats, cols, shcol = build_sprites()
    wbin("spr_pat.bin", pats)
    wbin("spr_col.bin", cols)
    wbin("spr_shcol.bin", shcol)
    t = build_tables()
    for k, v in t.items():
        wbin(k + ".bin", v)
    # object info table: per type 8 scales x (sx, sy, w, h)
    oi = bytearray()
    for tt in range(len(OBJ_TYPES)):
        for (x, y, w, h) in entries[tt]:
            oi += bytes([x, y + SHEET_Y0, w, h])
    wbin("objinfo.bin", oi)
    # font map: ascii 32..127 -> glyph index
    fm = bytearray([0] * 96)
    for i, ch in enumerate(FONT_ORDER):
        fm[ord(ch) - 32] = i
    for ch in "abcdefghijklmnopqrstuvwyz":
        fm[ord(ch) - 32] = FONT_ORDER.index(ch.upper())
    wbin("fontmap.bin", fm)
    lines = []
    lines.append(f"TITLE_Y equ {ty0}")
    lines.append(f"TITLE_H equ {th}")
    lines.append(f"FONT_Y equ {FONT_Y}")
    lines.append(f"BAND_Y equ {BAND_Y}")
    lines.append(f"BAND_H equ {BAND_H}")
    dsheets, dinfo, dprev = build_drops()
    for i, b in enumerate(dsheets):
        wbin(f"drop{i}.bin", b)
    wbin("dropinfo.bin", bytes(v for e in dinfo for v in e))
    for i, cd in enumerate(COURSES):
        seg_b, obj_b, pal_b, ld, n = build_course(cd)
        wbin(f"c{i}_seg.bin", seg_b)
        wbin(f"c{i}_obj.bin", obj_b)
        wbin(f"c{i}_pal.bin", pal_b)
        wbin(f"c{i}_ld.bin", ld)
        print(f"course {i} {cd['name']}: {len(seg_b)//3} segs, {n} objs")
    with open(os.path.join(OUT, "gen.inc"), "w") as f:
        f.write("\n".join(lines) + "\n")
    for fn in sorted(os.listdir(OUT)):
        print(fn, os.path.getsize(os.path.join(OUT, fn)))
    # previews
    try:
        from PIL import Image
        P = [(0,0,0),(60,190,40),(60,190,40),(60,190,40),(60,190,40),(190,130,70),(190,130,70),(190,130,70),(190,130,70),
             (255,255,255),(110,170,255),(70,70,130),(255,40,40),(255,220,40),(140,70,30),(40,130,40)]
        def show(img, name, w, h):
            im = Image.new("RGB", (w, h))
            for y in range(h):
                for x in range(w):
                    im.putpixel((x, y), P[img[y][x]])
            im.resize((w * 3, h * 3), Image.NEAREST).save(os.path.join(OUT, name))
        show(sheet, "prev_sheet.png", 256, 140)
        allp = [row for p in dprev for row in p + [[0]*256]]
        show(allp, "prev_drops.png", 256, len(allp))
        show(title, "prev_title.png", 256, th)
    except ImportError:
        pass

if __name__ == "__main__":
    main()
