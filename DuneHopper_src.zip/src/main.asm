;=====================================================================
; DUNE HOPPER - an original off-road racer for MSX2 (screen 5)
; ASCII16 megaROM, 64KB.  Assemble with sjasmplus.
;=====================================================================
        OUTPUT "build/dunehop.rom"
        INCLUDE "build/gen.inc"

;---------------------------------------------------------- hardware
VDP_DATA equ 0x98
VDP_CTRL equ 0x99
VDP_PAL  equ 0x9A
VDP_IND  equ 0x9B
PSG_ADR  equ 0xA0
PSG_WR   equ 0xA1
PSG_RD   equ 0xA2
PPI_B    equ 0xA9
PPI_C    equ 0xAA

RSLREG   equ 0x0138
ENASLT   equ 0x0024
EXPTBL   equ 0xFCC1
H_TIMI   equ 0xFD9F
RG9SAV   equ 0xFFE8

BANK2    equ 0x7000          ; ASCII16 bank register for 0x8000-0xBFFF

;---------------------------------------------------------- game constants
ROWS     equ 116
ZCAR     equ 36
ZNEAR    equ 26
ZFAR     equ 820
NOBJMAX  equ 20
MAXRECT  equ 30

J_UP     equ 1
J_DOWN   equ 2
J_LEFT   equ 4
J_RIGHT  equ 8
J_FIRE   equ 16

T_TREE   equ 0
T_ROCK   equ 1
T_LOG    equ 2
T_STAR   equ 3
T_POST   equ 4
T_BUSH   equ 5
T_SIGNL  equ 6
T_SIGNR  equ 7
T_GATE   equ 8
T_FINISH equ 9

SFX_JUMP  equ 1
SFX_STAR  equ 2
SFX_CRASH equ 3
SFX_LAND  equ 4
SFX_GATE  equ 5
SFX_TICK  equ 6
SFX_BONUS equ 7
SFX_FALL  equ 8
SFX_BOOM  equ 9
T_SHADOW equ 8
T_DROP   equ 10
DROP_HALF equ 24

MSG_NONE     equ 0
MSG_READY    equ 1
MSG_GO       equ 2
MSG_CHECK    equ 3
MSG_TIMEUP   equ 4
MSG_GAMEOVER equ 5
MSG_CLEAR    equ 6
MSG_BONUS    equ 7
MSG_C1       equ 8
MSG_DODGE    equ 11
MSG_DROP0    equ 12

;---------------------------------------------------------- RAM
RAMP = 0xC000
        MACRO VAR _n?, _s?
_n? EQU RAMP
RAMP = RAMP + _s?
        ENDM

        VAR isrOn,1
        VAR vblTotal,2
        VAR joy,1
        VAR speed,2
        VAR camz,3
        VAR playerX,2
        VAR curvCur,1
        VAR crashT,1
        VAR airOn,1
        VAR airH,2
        VAR airV,2
        VAR offroad,1
        VAR lockCtl,1
        VAR flipReq,1
        VAR flipVal,1
        VAR sprShown,1
        VAR carSX,1
        VAR timeBCD,1
        VAR tick,1
        VAR fps,1
        VAR timerOn,1
        VAR timeUp,1
        VAR palPhase,1
        VAR ldPal,8
        VAR sfx,1
        VAR sfxT,1
        VAR score,3
        VAR hiscore,3
        VAR course,1
        VAR stage,1
        VAR finished,1
        VAR bp,1
        VAR drawPage,1
        VAR segBase,2
        VAR objBase,2
        VAR segPtr,2
        VAR objStart,2
        VAR objPass,2
        VAR coll1,2
        VAR coll2,2
        VAR cz,2
        VAR px,1
        VAR airborne,1
        VAR prevC,1
        VAR tmpC,1
        VAR rowR,1
        VAR unew,1
        VAR X0,2
        VAR X1,2
        VAR fS,2
        VAR fE,2
        VAR lim,2
        VAR pdPtr,2
        VAR bMin,2
        VAR bMax,2
        VAR bFirst,1
        VAR bLast,1
        VAR bCnt,1
        VAR msgId,1
        VAR msgUntil,2
        VAR runEnd,2
        VAR hudPtr,2
        VAR oZ,2
        VAR oD,2
        VAR oT,1
        VAR oX,1
        VAR oXs,1
        VAR oR,1
        VAR oSX,1
        VAR oSY,1
        VAR oW,1
        VAR oH,1
        VAR oL,2
        VAR oBot,1
        VAR oTop,1
        VAR oDX,1
        VAR oGT,1
        VAR gL,2
        VAR gR,2
        VAR rX,1
        VAR rY,1
        VAR rNB,1
        VAR rNY,1
        VAR cmdbuf,15
        VAR hud0,6
        VAR hud1,6
        VAR msgBuf,32
        VAR rects0,1+MAXRECT*4
        VAR rects1,1+MAXRECT*4
        VAR sbuf,ROWS*2
        VAR dxb,ROWS            ; dxb, cleanDx, pageDx0, pageDx1 must stay contiguous
        VAR cleanDx,ROWS
        VAR pageDx0,ROWS
        VAR pageDx1,ROWS
        VAR frames,2
        VAR heading,2
        VAR sNow,1
        VAR pageShift0,1
        VAR pageShift1,1
        VAR bandDone,1
        VAR oPage,1
        VAR oLift,1
        VAR dState,1
        VAR dTimer,2
        VAR dType,1
        VAR dChunk,1
        VAR dZ,2
        VAR dX,1
        VAR dH,1
        VAR dLastV,2
        VAR dPassed,1
        VAR dPend,1
        VAR rnd,2
        VAR eY0,1
        VAR eY1,1
        VAR ramEnd,0

CB_SX  equ cmdbuf+0
CB_SY  equ cmdbuf+2
CB_DX  equ cmdbuf+4
CB_DY  equ cmdbuf+6
CB_NX  equ cmdbuf+8
CB_NY  equ cmdbuf+10
CB_CLR equ cmdbuf+12
CB_ARG equ cmdbuf+13
CB_CMD equ cmdbuf+14

        ASSERT ramEnd < 0xF000

;=====================================================================
; BANK 0  (0x4000-0x7FFF) : code + small tables
;=====================================================================
        ORG 0x4000
        db "AB"
        dw start
        dw 0,0,0
        ds 6,0

start:
        di
        im 1
        ld sp,0xF380
        ; --- make page 2 (0x8000) point to our cartridge slot
        call RSLREG
        rrca
        rrca
        and 3
        ld c,a
        ld b,0
        ld hl,EXPTBL
        add hl,bc
        ld a,(hl)
        and 0x80
        or c
        ld c,a
        inc hl
        inc hl
        inc hl
        inc hl
        ld a,(hl)
        and 0x0C
        or c
        ld h,0x80
        call ENASLT
        di
        ld sp,0xF380
        ld a,1
        ld (BANK2),a
        ; --- clear RAM vars
        ld hl,0xC000
        ld de,0xC001
        ld bc,ramEnd-0xC000
        ld (hl),0
        ldir
        call psgInit
        call initVdp
        call loadGfx
        ; hiscore default 005000
        ld a,0x50
        ld (hiscore+1),a
        ; --- install interrupt hook
        di
        ld a,0xC3
        ld (H_TIMI),a
        ld hl,isr
        ld (H_TIMI+1),hl
        ei
        jp titleScreen

;---------------------------------------------------------- PSG
psgInit:
        ld b,14
        ld c,0
.l:     ld a,c
        out (PSG_ADR),a
        xor a
        cp c
        ld a,0
        jr nz,.w
        ld a,0
.w:     ld a,c
        cp 7
        ld a,0
        jr nz,.w2
        ld a,0xBF
.w2:    out (PSG_WR),a
        inc c
        djnz .l
        ret

;---------------------------------------------------------- VDP basics
wrReg:  ; A=value, B=register
        out (VDP_CTRL),a
        ld a,b
        or 0x80
        out (VDP_CTRL),a
        ret

initVdp:
        di
        ld hl,vdpInitTab
.l:     ld b,(hl)
        inc hl
        ld a,b
        cp 0xFF
        jr z,.d
        ld a,(hl)
        inc hl
        call wrReg
        jr .l
.d:     ld a,(RG9SAV)
        and 2
        ld c,a
        or 0x80
        ld b,9
        call wrReg
        ld a,c
        or a
        ld a,60
        jr z,.f
        ld a,50
.f:     ld (fps),a
        ; palette all black
        xor a
        out (VDP_CTRL),a
        ld a,0x90
        out (VDP_CTRL),a
        ld b,32
        xor a
.p:     out (VDP_PAL),a
        djnz .p
        ; clear all 128K VRAM with HMMV
        ld hl,0
        ld (CB_DX),hl
        ld (CB_DY),hl
        ld hl,256
        ld (CB_NX),hl
        ld hl,512
        ld (CB_NY),hl
        xor a
        ld (CB_CLR),a
        ld (CB_ARG),a
        ld a,0xC0
        ld (CB_CMD),a
        call vdpcmd
        ld hl,512
        ld (CB_DY),hl
        call vdpcmd
        call vdpwait
        di
        ret

vdpInitTab:
        db 0,0x06, 1,0x22, 2,0x1F, 3,0xFF, 4,0x00, 5,0x17, 6,0x30, 7,0x00
        db 8,0x08, 10,0x00, 11,0x03, 14,0x00, 15,0x00, 16,0x00, 18,0x00
        db 19,0x00, 23,0x00
        db 0xFF

; Wait for VDP command engine idle. Leaves interrupts enabled.
vdpwait:
        di
        ld a,2
        out (VDP_CTRL),a
        ld a,0x8F
        out (VDP_CTRL),a
        in a,(VDP_CTRL)
        rra
        ld a,0
        out (VDP_CTRL),a
        ld a,0x8F
        ei
        out (VDP_CTRL),a
        jr c,vdpwait
        ret

; Issue the 15-byte command in cmdbuf (R#32..R#46)
vdpcmd:
        call vdpwait
        di
        ld a,32
        out (VDP_CTRL),a
        ld a,0x91
        out (VDP_CTRL),a
        ld hl,cmdbuf
        ld bc,15*256+VDP_IND
        otir
        ei
        ret

; set VRAM write address: A = bit16, HL = bits 15..0. Leaves DI.
setVramW:
        di
        ld b,a
        ld a,h
        rlca
        rlca
        and 3
        sla b
        sla b
        or b
        out (VDP_CTRL),a
        ld a,0x8E
        out (VDP_CTRL),a
        ld a,l
        out (VDP_CTRL),a
        ld a,h
        and 0x3F
        or 0x40
        out (VDP_CTRL),a
        ret

; RLE -> VRAM data port.  HL = src, DE = output byte count
rle2vram:
.lp:    ld a,d
        or e
        ret z
        ld a,(hl)
        inc hl
        bit 7,a
        jr nz,.run
        inc a
        ld b,a
.lit:   ld a,(hl)
        out (VDP_DATA),a
        inc hl
        dec de
        djnz .lit
        jr .lp
.run:   and 0x7F
        inc a
        ld b,a
        ld a,(hl)
        inc hl
.rl:    out (VDP_DATA),a
        dec de
        nop
        djnz .rl
        jr .lp

; HL = src, BC = count
outBlock:
.l:     ld a,(hl)
        out (VDP_DATA),a
        inc hl
        dec bc
        ld a,b
        or c
        jr nz,.l
        ret

loadGfx:
        ld a,2
        ld (BANK2),a
        ld a,1                  ; road rows -> page 2 line 0
        ld hl,0x0000
        call setVramW
        ld hl,gRoad
        ld de,ROWS*128
        call rle2vram
        ld a,1                  ; object sheet + font -> page 2 line 116
        ld hl,116*128
        call setVramW
        ld hl,gSheet
        ld de,140*128
        call rle2vram
        ld a,1                  ; sky -> page 3 line 24
        ld hl,0x8000+24*128
        call setVramW
        ld hl,gSky
        ld de,72*128
        call rle2vram
        ld a,1                  ; sprite patterns 0x18000
        ld hl,0x8000
        call setVramW
        ld hl,gSprPat
        ld bc,832
        call outBlock
        ld a,1                  ; shadow sprite colours (sprites 8,9)
        ld hl,0x8880
        call setVramW
        ld hl,gShCol
        ld bc,16
        call outBlock
        ld hl,gShCol
        ld bc,16
        call outBlock
        ld a,1                  ; SAT: terminate
        ld hl,0x8A00
        call setVramW
        ld a,216
        out (VDP_DATA),a
        ld a,1
        ld (BANK2),a
        ld a,0xFF
        ld (sprShown),a
        ret

;=====================================================================
; Interrupt (H.TIMI hook) - runs every vblank
;=====================================================================
isr:
        push af
        push bc
        push de
        push hl
        ld a,(isrOn)
        or a
        jp z,.out
        ld a,(flipReq)
        or a
        jr z,.nf
        ld a,(flipVal)
        out (VDP_CTRL),a
        ld a,0x82
        out (VDP_CTRL),a
        xor a
        ld (flipReq),a
.nf:    ld hl,(vblTotal)
        inc hl
        ld (vblTotal),hl
        call readInput
        ld a,(isrOn)
        cp 2
        jr nz,.title
        call physics
        call timerTick
        jr .com
.title: ld hl,(camz+1)
        inc hl
        inc hl
        ld (camz+1),hl
.com:   call stripePal
        call updSprites
        call sound
.out:   pop hl
        pop de
        pop bc
        pop af
        ret

readInput:
        in a,(PPI_C)
        and 0xF0
        or 8
        out (PPI_C),a
        in a,(PPI_B)
        cpl
        ld e,a
        ld d,0
        bit 5,e
        jr z,.r1
        set 0,d
.r1:    bit 6,e
        jr z,.r2
        set 1,d
.r2:    bit 4,e
        jr z,.r3
        set 2,d
.r3:    bit 7,e
        jr z,.r4
        set 3,d
.r4:    bit 0,e
        jr z,.r5
        set 4,d
.r5:    ld e,0x00               ; joystick port 1
        call .port
        ld e,0x40               ; joystick port 2
        call .port
        ld a,d
        ld (joy),a
        ret
; read one joystick port and OR it into D, unless it reports impossible
; combinations (left+right or up+down) - e.g. a mouse plugged in that port
.port:  ld a,15
        out (PSG_ADR),a
        in a,(PSG_RD)
        and 0xBF
        or e
        out (PSG_WR),a
        ld a,14
        out (PSG_ADR),a
        in a,(PSG_RD)
        cpl
        and 0x1F
        ld c,a
        and 0x03
        cp 0x03
        ret z
        ld a,c
        and 0x0C
        cp 0x0C
        ret z
        ld a,c
        or d
        ld d,a
        ret

physics:
        ld a,(lockCtl)
        or a
        jr z,.nl
        ld hl,(speed)
        ld de,-24
        add hl,de
        jr c,.lk
        ld hl,0
.lk:    ld (speed),hl
        jp .move
.nl:    ld a,(crashT)
        or a
        jr z,.nocr
        dec a
        ld (crashT),a
        ld hl,0
        ld (speed),hl
        jp nz,.move
        ld a,(playerX+1)        ; crash over: back towards the track
        or a
        jp p,.cp
        neg
        cp 73
        jp c,.move
        ld hl,0xC800
        ld (playerX),hl
        jp .move
.cp:    cp 73
        jp c,.move
        ld hl,0x3800
        ld (playerX),hl
        jp .move
.nocr:  ld hl,(speed)
        ld a,(joy)
        and J_UP|J_FIRE
        jr z,.noacc
        ld de,7
        add hl,de
        jr .lim
.noacc: ld a,(joy)
        and J_DOWN
        ld de,-3
        jr z,.dc
        ld de,-28
.dc:    add hl,de
        jr c,.lim
        ld hl,0
.lim:   ld de,1536
        ld a,(offroad)
        or a
        jr z,.l2
        ld de,560
.l2:    push hl
        or a
        sbc hl,de
        pop hl
        jr c,.sok
        jr z,.sok
        ld a,(offroad)
        or a
        jr z,.clamp
        ld de,-20
        add hl,de
        jr .sok
.clamp: ex de,hl
.sok:   ld (speed),hl
        ; steering amount = (speed/4) + 64  (8.8 units)
        srl h
        rr l
        srl h
        rr l
        ld a,h
        or l
        jr z,.nost
        ld de,64
        add hl,de
.nost:  ex de,hl
        ld hl,(playerX)
        ld a,(joy)
        bit 2,a
        jr z,.ns1
        or a
        sbc hl,de
.ns1:   ld a,(joy)
        bit 3,a
        jr z,.ns2
        add hl,de
.ns2:   push hl
        ld hl,(speed)           ; drift = curv * speed/16
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ex de,hl
        ld hl,0
        ld a,(curvCur)
        or a
        jr z,.dd
        jp p,.dp
        neg
        ld b,a
.dn:    or a
        sbc hl,de
        djnz .dn
        jr .dd
.dp:    ld b,a
.dq:    add hl,de
        djnz .dq
.dd:    ex de,hl
        ld hl,(heading)
        add hl,de
        ld (heading),hl
        pop hl
        or a
        sbc hl,de
        bit 7,h
        jr nz,.cn
        ld a,h
        cp 0x78
        jr c,.cok
        ld hl,0x7800
        jr .cok
.cn:    ld a,h
        cp 0x88
        jr nc,.cok
        ld hl,0x8800
.cok:   ld (playerX),hl
        ld a,h
        or a
        jp p,.op
        neg
.op:    cp 71
        ld a,0
        jr c,.of
        inc a
.of:    ld (offroad),a
.move:  ld hl,(camz)
        ld de,(speed)
        add hl,de
        ld (camz),hl
        jr nc,.mc
        ld hl,camz+2
        inc (hl)
.mc:    ld a,(airOn)
        or a
        ret z
        ld hl,(airH)
        ld de,(airV)
        add hl,de
        ld (airH),hl
        ex de,hl
        ld de,-0x18
        add hl,de
        ld (airV),hl
        ld a,(airH+1)
        bit 7,a
        ret z
        ld hl,0
        ld (airH),hl
        xor a
        ld (airOn),a
        ld a,SFX_LAND
        jp sfxStartI

timerTick:
        ld a,(timerOn)
        or a
        ret z
        ld hl,tick
        inc (hl)
        ld a,(fps)
        cp (hl)
        ret nz
        ld (hl),0
        ld a,(timeBCD)
        or a
        jr z,.up
        sub 1
        daa
        ld (timeBCD),a
        jr z,.up
        cp 6
        ret nc
        ld a,SFX_TICK
        jp sfxStartI
.up:    ld a,1
        ld (timeUp),a
        xor a
        ld (timerOn),a
        ret

; stripes: palette entries 1..8 rotate light/dark with distance travelled
stripePal:
        ld a,(camz+1)
        add a,4
        rrca
        rrca
        rrca
        and 3
        ld hl,palPhase
        cp (hl)
        ret z
        ld (hl),a
        ld c,a
        ld a,1
        out (VDP_CTRL),a
        ld a,0x90
        out (VDP_CTRL),a
        ld e,0
        call .four
        ld e,4
.four:  ld b,0
.lp:    ld a,b
        add a,c
        and 3
        cp 2
        ld a,e
        jr c,.lt
        add a,2
.lt:    ld hl,ldPal
        add a,l
        ld l,a
        jr nc,.nc
        inc h
.nc:    ld a,(hl)
        out (VDP_PAL),a
        inc hl
        ld a,(hl)
        out (VDP_PAL),a
        inc b
        ld a,b
        cp 4
        jr nz,.lp
        ret

sprOut: ; H=y, L=x, E=pattern -> 4 bytes, E+=4
        ld a,h
        out (VDP_DATA),a
        ld a,l
        out (VDP_DATA),a
        ld a,e
        out (VDP_DATA),a
        out (VDP_DATA),a
        add a,4
        ld e,a
        ret

updSprites:
        ld b,0
        ld a,(isrOn)
        cp 2
        jr nz,.fs
        ld a,(crashT)
        or a
        jr nz,.fs
        ld a,(lockCtl)
        or a
        jr nz,.fs
        ld a,(joy)
        bit 2,a
        jr z,.f1
        ld b,1
        jr .fs
.f1:    bit 3,a
        jr z,.fs
        ld b,2
.fs:    ld a,(sprShown)
        cp b
        jr z,.nocol
        ld a,b
        ld (sprShown),a
        ld a,6
        out (VDP_CTRL),a
        ld a,0x8E
        out (VDP_CTRL),a
        xor a
        out (VDP_CTRL),a
        ld a,0x48
        out (VDP_CTRL),a
        ld h,b
        ld l,0
        srl h
        rr l
        ld de,sprCol
        add hl,de
        ld b,128
.cl:    ld a,(hl)
        out (VDP_DATA),a
        inc hl
        djnz .cl
.nocol: ld a,(playerX+1)        ; screen x = 112 + px*27/16
        ld l,a
        rla
        sbc a,a
        ld h,a
        ld d,h
        ld e,l
        add hl,hl
        push hl
        add hl,hl
        add hl,hl
        ld b,h
        ld c,l
        add hl,hl
        add hl,bc
        pop bc
        add hl,bc
        add hl,de
        sra h
        rr l
        sra h
        rr l
        sra h
        rr l
        sra h
        rr l
        ld de,112
        add hl,de
        ld a,h
        or a
        jr z,.x1
        ld l,0
        jp m,.x1
        ld l,224
.x1:    ld a,l
        cp 225
        jr c,.x2
        ld a,224
.x2:    ld (carSX),a
        ld a,(airH+1)
        ld b,a
        ld a,183
        sub b
        ld c,a
        ld a,(crashT)
        or a
        jr z,.nb
        ld a,(vblTotal)
        and 4
        jr z,.nb
        ld c,230
.nb:    ld a,6
        out (VDP_CTRL),a
        ld a,0x8E
        out (VDP_CTRL),a
        xor a
        out (VDP_CTRL),a
        ld a,0x4A
        out (VDP_CTRL),a
        ld a,(sprShown)
        add a,a
        add a,a
        add a,a
        add a,a
        add a,a
        ld e,a
        ld a,(carSX)
        ld d,a
        ld b,2
.lay:   ld h,c
        ld l,d
        call sprOut
        ld a,d
        add a,16
        ld l,a
        call sprOut
        ld a,c
        add a,16
        ld h,a
        ld l,d
        call sprOut
        ld a,d
        add a,16
        ld l,a
        call sprOut
        djnz .lay
        ld h,230                ; shadow
        ld a,(airOn)
        or a
        jr z,.ns
        ld a,c
        cp 200
        jr nc,.ns
        ld h,202
.ns:    ld l,d
        ld e,96
        call sprOut
        ld a,d
        add a,16
        ld l,a
        call sprOut
        ld a,216
        out (VDP_DATA),a
        ret

;---------------------------------------------------------- sound
psgw:   ; A=reg, E=value
        out (PSG_ADR),a
        ld a,e
        out (PSG_WR),a
        ret

sound:
        ld e,0
        ld a,(isrOn)
        cp 2
        jr nz,.eng
        ld hl,(speed)
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld d,h
        ld e,l
        add hl,hl
        add hl,de
        ex de,hl
        ld hl,900
        or a
        sbc hl,de
        ld a,(vblTotal)
        and 1
        add a,a
        add a,a
        add a,a
        add a,l
        ld l,a
        jr nc,.w
        inc h
.w:     ld e,l
        xor a
        call psgw
        ld e,h
        ld a,1
        call psgw
        ld e,9
        ld a,(timeUp)
        or a
        jr z,.eng
        ld e,0
.eng:   ld a,8
        call psgw
        ld e,0x9C
        ld a,7
        call psgw
        ld a,(sfxT)
        or a
        jr nz,.sfx
        ld e,0
        ld a,9
        call psgw
        ld a,10
        jp psgw
.sfx:   dec a
        ld (sfxT),a
        ld c,a
        ld a,(sfx)
        cp SFX_JUMP
        jr z,.jump
        cp SFX_STAR
        jr z,.star
        cp SFX_CRASH
        jp z,.crash
        cp SFX_LAND
        jp z,.land
        cp SFX_GATE
        jr z,.gate
        cp SFX_TICK
        jr z,.tick
        cp SFX_FALL
        jr z,.fall
        cp SFX_BOOM
        jr z,.boom
        ; bonus
        ld hl,60
        ld b,11
        jr .tone
.jump:  ld a,c                  ; rising sweep
        add a,a
        add a,a
        add a,c
        add a,c
        ld l,a
        ld h,0
        add hl,hl
        ld de,60
        add hl,de
        ld b,12
        jr .tone
.star:  ld hl,95
        bit 2,c
        jr z,.s1
        ld hl,71
.s1:    ld b,13
        jr .tone
.gate:  ld a,c
        srl a
        srl a
        srl a
        and 3
        ld hl,gateNotes
        add a,a
        add a,l
        ld l,a
        jr nc,.g1
        inc h
.g1:    ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        ld b,13
        jr .tone
.fall:  ld a,60                  ; descending whistle
        sub c
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        ld de,50
        add hl,de
        ld b,11
        jr .tone
.boom:  ld e,31
        ld a,6
        call psgw
        ld a,c
        srl a
        srl a
        add a,2
        cp 16
        jr c,.bm
        ld a,15
.bm:    ld b,a
        jr .nz
.tick:  ld hl,400
        ld b,12
.tone:  ld e,l
        ld a,2
        call psgw
        ld e,h
        ld a,3
        call psgw
        ld e,b
        ld a,9
        call psgw
        ld e,0
        ld a,10
        jp psgw
.crash: ld a,c
        srl a
        add a,4
        cp 16
        jr c,.c1
        ld a,15
.c1:    ld b,a
        ld a,c
        and 7
        add a,20
        ld e,a
        ld a,6
        call psgw
        jr .nz
.land:  ld e,26
        ld a,6
        call psgw
        ld a,c
        add a,6
        ld b,a
.nz:    ld e,b
        ld a,10
        call psgw
        ld e,0
        ld a,9
        jp psgw

gateNotes:
        dw 214,170,143,107

sfxStartI:
        ld (sfx),a
        push hl
        ld hl,sfxLen-1
        add a,l
        ld l,a
        jr nc,.n
        inc h
.n:     ld a,(hl)
        ld (sfxT),a
        pop hl
        ret
sfxLen: db 20,18,36,8,32,6,3,60,50

sfxStart:
        di
        call sfxStartI
        ei
        ret

;=====================================================================
; Title screen
;=====================================================================
titleScreen:
        xor a
        ld (course),a
        call setupCourse
        xor a
        ld (isrOn),a
        ld (msgId),a
        ; clear HUD band of page 0
        ld hl,0
        ld (CB_DX),hl
        ld (CB_DY),hl
        ld hl,256
        ld (CB_NX),hl
        ld hl,24
        ld (CB_NY),hl
        xor a
        ld (CB_CLR),a
        ld a,0xC0
        ld (CB_CMD),a
        call vdpcmd
        call vdpwait
        ; title logo band
        ld a,2
        ld (BANK2),a
        xor a
        ld hl,TITLE_Y*128
        call setVramW
        ld hl,gTitle
        ld de,TITLE_H*128
        call rle2vram
        ld a,1
        ld (BANK2),a
        ei
        xor a
        ld (drawPage),a
        ld hl,tHi
        ld de,72*256+6
        call drawText
        ld de,144*256+6
        ld hl,hiscore+2
        ld b,3
.hs:    ld a,(hl)
        push hl
        push bc
        call drawBCD
        pop bc
        pop hl
        dec hl
        djnz .hs
        ld hl,tPress
        ld de,52*256+112
        call drawText
        ld hl,tCtl1
        ld de,32*256+134
        call drawText
        ld hl,tCtl2
        ld de,24*256+146
        call drawText
        ld hl,tOrig
        ld de,44*256+166
        call drawText
        call vdpwait
        ld hl,0
        ld (playerX),hl
        ld (airH),hl
        xor a
        ld (crashT),a
        ld (airOn),a
        ld a,1
        ld (isrOn),a
.w1:    ld a,(joy)
        and J_FIRE
        jr nz,.w1
.w2:    ld a,(joy)
        and J_FIRE
        jr z,.w2
        ld hl,(vblTotal)
        ld a,r
        xor l
        ld l,a
        set 0,l
        ld (rnd),hl
        ld hl,0
        ld (score),hl
        xor a
        ld (score+2),a
        ld (course),a
        jp gameStart

tHi:    db "HI-SCORE",0
tPress: db "PRESS SPACE OR FIRE",0
tCtl1:  db "STEER: CURSORS/STICK",0
tCtl2:  db "GAS: SPACE/UP  BRAKE: DOWN",0
tOrig:  db "AN ORIGINAL MSX2 GAME",0

;=====================================================================
; Game flow
;=====================================================================
gameStart:
courseLoop:
        call setupCourse
        ld a,(course)
        add a,MSG_C1
        call setMsg
        ld de,100
        call runFor
        ld a,MSG_READY
        call setMsg
        ld a,SFX_TICK
        call sfxStart
        ld de,60
        call runFor
        ld a,MSG_GO
        call setMsg
        ld a,SFX_GATE
        call sfxStart
        xor a
        ld (lockCtl),a
        ld a,1
        ld (timerOn),a
        call dropSchedule
playLoop:
        call frame
        call msgExpire
        ld a,(timeUp)
        or a
        jr nz,timeOver
        ld a,(finished)
        or a
        jr nz,courseClear
        jr playLoop

timeOver:
        ld a,1
        ld (lockCtl),a
        ld a,MSG_TIMEUP
        call setMsg
        ld de,150
        call runFor
        ld a,MSG_GAMEOVER
        call setMsg
        ld de,150
        call runFor
        call updateHi
        jp titleScreen

courseClear:
        ld a,1
        ld (lockCtl),a
        xor a
        ld (timerOn),a
        ld a,MSG_CLEAR
        call setMsg
        ld de,100
        call runFor
        ld a,MSG_BONUS
        call setMsg
.tally: ld a,(timeBCD)
        or a
        jr z,.td
        sub 1
        daa
        ld (timeBCD),a
        ld a,0x01
        call addScore100
        ld a,SFX_BONUS
        call sfxStart
        call frame
        ld a,MSG_BONUS
        call setMsg
        jr .tally
.td:    ld de,90
        call runFor
        call updateHi
        ld a,(course)
        inc a
        cp 3
        jr c,.nc
        xor a
.nc:    ld (course),a
        jp courseLoop

runFor: ; DE = vblanks to keep rendering
        ld hl,(vblTotal)
        add hl,de
        ld (runEnd),hl
.l:     call frame
        call msgExpire
        ld hl,(vblTotal)
        ld de,(runEnd)
        or a
        sbc hl,de
        jp m,.l
        ret

setMsg: ld (msgId),a
        ld hl,(vblTotal)
        ld de,150
        add hl,de
        ld (msgUntil),hl
        ret

msgExpire:
        ld a,(msgId)
        or a
        ret z
        ld hl,(vblTotal)
        ld de,(msgUntil)
        or a
        sbc hl,de
        ret m
        xor a
        ld (msgId),a
        ret

updateHi:
        ld a,(score+2)
        ld hl,hiscore+2
        cp (hl)
        jr c,.no
        jr nz,.yes
        ld a,(score+1)
        dec hl
        cp (hl)
        jr c,.no
        jr nz,.yes
        ld a,(score)
        dec hl
        cp (hl)
        jr c,.no
.yes:   ld hl,score
        ld de,hiscore
        ld bc,3
        ldir
.no:    ret

addScore100: ; A = BCD amount in hundreds
        ld hl,score+1
        add a,(hl)
        daa
        ld (hl),a
        inc hl
        ld a,(hl)
        adc a,0
        daa
        ld (hl),a
        ret

;---------------------------------------------------------- course setup
setupCourse:
        xor a
        ld (isrOn),a
        ld (flipReq),a
        ld a,(course)
        add a,a
        add a,a
        add a,a
        ld l,a
        ld h,0
        ld de,courseTab
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (segBase),de
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (objBase),de
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        push de
        ld e,(hl)
        inc hl
        ld d,(hl)
        ex de,hl
        ld de,ldPal
        ld bc,8
        ldir
        pop hl
        di
        xor a
        out (VDP_CTRL),a
        ld a,0x90
        out (VDP_CTRL),a
        ld bc,32*256+VDP_PAL
        otir
        ei
        ld a,0xFF
        ld (palPhase),a
        ; clean road: page2 rows -> page3 rows 96..211
        ld hl,0
        ld (CB_SX),hl
        ld (CB_DX),hl
        ld hl,512
        ld (CB_SY),hl
        ld hl,768+96
        ld (CB_DY),hl
        ld hl,256
        ld (CB_NX),hl
        ld hl,ROWS
        ld (CB_NY),hl
        ld a,0xD0
        ld (CB_CMD),a
        call vdpcmd
        ld hl,768+24            ; page3 -> page0 / page1
        ld (CB_SY),hl
        ld hl,24
        ld (CB_DY),hl
        ld hl,188
        ld (CB_NY),hl
        call vdpcmd
        ld hl,256+24
        ld (CB_DY),hl
        call vdpcmd
        ld hl,0                 ; HUD band black
        ld (CB_DY),hl
        ld hl,24
        ld (CB_NY),hl
        xor a
        ld (CB_CLR),a
        ld a,0xC0
        ld (CB_CMD),a
        call vdpcmd
        ld hl,256
        ld (CB_DY),hl
        call vdpcmd
        ld hl,dxb
        ld de,dxb+1
        ld bc,ROWS*4-1
        ld (hl),0
        ldir
        xor a
        ld (rects0),a
        ld (rects1),a
        ld hl,hud0
        ld de,hud0+1
        ld bc,11
        ld (hl),0xEE
        ldir
        xor a
        ld (drawPage),a
        call hudLabels
        ld a,1
        ld (drawPage),a
        call hudLabels
        ld hl,(segBase)
        ld (segPtr),hl
        ld hl,(objBase)
        ld (objStart),hl
        ld (objPass),hl
        ld hl,0xFFFF
        ld (coll1),hl
        ld (coll2),hl
        ld hl,0
        ld (camz),hl
        ld (playerX),hl
        ld (speed),hl
        ld (airH),hl
        ld (heading),hl
        xor a
        ld (pageShift0),a
        ld (pageShift1),a
        ld (dState),a
        ld (camz+2),a
        ld (airOn),a
        ld (crashT),a
        ld (timeUp),a
        ld (finished),a
        ld (timerOn),a
        ld (tick),a
        ld (offroad),a
        ld (msgId),a
        ld (curvCur),a
        inc a
        ld (stage),a
        ld (lockCtl),a
        ld (bp),a
        ld a,0x30
        ld (timeBCD),a
        di
        ld a,0x1F
        out (VDP_CTRL),a
        ld a,0x82
        out (VDP_CTRL),a
        ld a,0x62               ; display on, vblank irq, 16x16 sprites
        out (VDP_CTRL),a
        ld a,0x81
        out (VDP_CTRL),a
        ld a,2
        ld (isrOn),a
        ei
        ret

hudLabels:
        ld hl,tScore
        ld de,8*256+4
        call drawText
        ld hl,tTime
        ld de,120*256+4
        call drawText
        ld hl,tStage
        ld de,192*256+4
        jp drawText
tScore: db "SCORE",0
tTime:  db "TIME",0
tStage: db "STAGE",0

;=====================================================================
; One rendered frame
;=====================================================================
frame:
.wf:    ld a,(flipReq)
        or a
        jr nz,.wf
        di
        ld hl,(camz+1)
        ld (cz),hl
        ld a,(playerX+1)
        ld (px),a
        ld a,(heading+1)
        and 0xFC
        ld (sNow),a
        ld a,(airH+1)
        ei
        cp 3
        ld a,0
        jr c,.ab
        inc a
.ab:    ld (airborne),a
        call updSeg
        call collisions
        call dropLogic
        call computeDx
        call updClean
        call syncPage
        call bandUpdate
        call eraseObjs
        call drawObjs
        call drawHud
        call vdpwait
        ld a,(bp)
        or a
        ld a,0x1F
        jr z,.fv
        ld a,0x3F
.fv:    ld (flipVal),a
        ld a,1
        ld (flipReq),a
        ld a,(bp)
        xor 1
        ld (bp),a
        ld hl,(frames)
        inc hl
        ld (frames),hl
        ret

updSeg:
        ld hl,(segPtr)
.l:     push hl
        inc hl
        inc hl
        inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        ld hl,(cz)
        or a
        sbc hl,de
        pop hl
        jr c,.d
        inc hl
        inc hl
        inc hl
        jr .l
.d:     ld (segPtr),hl
        inc hl
        inc hl
        ld a,(hl)
        ld (curvCur),a
        ret

;---------------------------------------------------------- road curve -> dx per row
computeDx:
        ld hl,sbuf
        ld de,sbuf+1
        ld bc,ROWS*2-1
        ld (hl),0
        ldir
        ld hl,(segPtr)
        inc hl
        inc hl
        ld a,(hl)
        ld (prevC),a
        dec hl
        dec hl
        push hl
        ld hl,ftab
        call applyTerm
        pop hl
.nx:    inc hl
        inc hl
        inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld a,(hl)
        dec hl
        dec hl
        ld (tmpC),a
        push hl
        ex de,hl
        ld de,(cz)
        or a
        sbc hl,de
        ld a,h
        cp 4
        jr nc,.stop
        ld a,l
        and 0xE0
        or h
        rlca
        rlca
        rlca
        add a,a
        ld l,a
        ld h,0
        ld de,fPtrs
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        ld a,(prevC)
        ld b,a
        ld a,(tmpC)
        ld (prevC),a
        sub b
        ex de,hl
        call nz,applyTerm
        pop hl
        jr .nx
.stop:  pop hl
        ld hl,sbuf
        ld de,dxb
        ld b,ROWS
.cv:    ld c,(hl)
        inc hl
        ld a,(hl)
        inc hl
        or a
        jr z,.ps
        inc a
        jr z,.ng
        dec a
        ld a,126
        jp p,.ok
        ld a,0x82
        jr .ok
.ps:    ld a,c
        cp 127
        jr c,.ok
        ld a,126
        jr .ok
.ng:    ld a,c
        cp 0x82
        jr nc,.ok
        ld a,0x82
.ok:    and 0xFE
        ld (de),a
        inc de
        djnz .cv
        ret

applyTerm:      ; HL = F row, A = signed delta
        or a
        ret z
        jp m,.neg
.pl:    cp 2
        jr c,.p1
        push af
        push hl
        call add2
        pop hl
        pop af
        sub 2
        ret z
        jr .pl
.p1:    jp add1
.neg:   neg
.nl:    cp 2
        jr c,.n1
        push af
        push hl
        call sub2
        pop hl
        pop af
        sub 2
        ret z
        jr .nl
.n1:    jp sub1

add1:   ld de,sbuf
        ld b,ROWS
.l:     ld a,(de)
        add a,(hl)
        ld (de),a
        inc de
        jr nc,.n
        ld a,(de)
        inc a
        ld (de),a
.n:     inc de
        inc hl
        djnz .l
        ret
add2:   ld de,sbuf
        ld b,ROWS
.l:     ld a,(hl)
        add a,a
        ld c,a
        ld a,(de)
        add a,c
        ld (de),a
        inc de
        jr nc,.n
        ld a,(de)
        inc a
        ld (de),a
.n:     inc de
        inc hl
        djnz .l
        ret
sub1:   ld de,sbuf
        ld b,ROWS
.l:     ld a,(de)
        sub (hl)
        ld (de),a
        inc de
        jr nc,.n
        ld a,(de)
        dec a
        ld (de),a
.n:     inc de
        inc hl
        djnz .l
        ret
sub2:   ld de,sbuf
        ld b,ROWS
.l:     ld a,(hl)
        add a,a
        ld c,a
        ld a,(de)
        sub c
        ld (de),a
        inc de
        jr nc,.n
        ld a,(de)
        dec a
        ld (de),a
.n:     inc de
        inc hl
        djnz .l
        ret

;---------------------------------------------------------- span helpers
max16:  push hl                 ; HL = max(HL,DE) unsigned
        or a
        sbc hl,de
        pop hl
        ret nc
        ex de,hl
        ret
min16:  push hl                 ; HL = min(HL,DE) unsigned
        or a
        sbc hl,de
        pop hl
        ret c
        ex de,hl
        ret

; B = old dx, C = new dx, (rowR) -> X0, X1 (biased +128, even), unew
spanCalc:
        ld a,(rowR)
        ld l,a
        ld h,0
        ld de,extTab
        add hl,de
        ld e,(hl)
        ld a,b
        xor 0x80
        ld d,a
        ld a,c
        xor 0x80
        ld (unew),a
        cp d
        jr c,.nl
        ld l,d
        ld h,a
        jr .g
.nl:    ld l,a
        ld h,d
.g:     push hl
        ld h,0
        ld d,0
        ld bc,128
        add hl,bc
        or a
        sbc hl,de
        res 0,l
        ld (X0),hl
        pop hl
        ld l,h
        ld h,0
        add hl,bc
        add hl,de
        inc hl
        res 0,l
        ld (X1),hl
        ret

updClean:
        ld hl,dxb
        ld de,cleanDx
        xor a
        ld (rowR),a
.l:     ld a,(de)
        cp (hl)
        jr z,.n
        push hl
        push de
        ld b,a
        ld c,(hl)
        ld a,c
        ld (de),a
        call cleanRow
        pop de
        pop hl
.n:     inc hl
        inc de
        ld a,(rowR)
        inc a
        ld (rowR),a
        cp ROWS
        jr nz,.l
        ret

cleanRow:
        call spanCalc
        ld hl,(X0)
        ld a,(unew)
        ld e,a
        ld d,0
        or a
        sbc hl,de
        jr nc,.nol
        ld hl,(X0)
        ld (fS),hl
        ld (fE),de
        ld hl,(X1)
        ld de,(fE)
        call min16
        ld (fE),hl
        call fillGrass
        ld a,(unew)
        ld l,a
        ld h,0
        ld (X0),hl
.nol:   ld a,(unew)
        ld l,a
        ld h,1
        ld (lim),hl
        ex de,hl
        ld hl,(X1)
        or a
        sbc hl,de
        jr c,.nor
        jr z,.nor
        ld (fS),de
        ld hl,(X0)
        ld de,(fS)
        call max16
        ld (fS),hl
        ld hl,(X1)
        ld (fE),hl
        call fillGrass
        ld hl,(lim)
        ld (X1),hl
.nor:   ld hl,(X0)
        ld de,128
        call max16
        ld (X0),hl
        ld hl,(X1)
        ld de,384
        call min16
        ld de,(X0)
        or a
        sbc hl,de
        ret c
        ret z
        ld (CB_NX),hl
        ld hl,(X0)
        ld a,(unew)
        ld e,a
        ld d,0
        or a
        sbc hl,de
        ld (CB_SX),hl
        ld hl,(X0)
        ld de,-128
        add hl,de
        ld (CB_DX),hl
        ld a,(rowR)
        ld l,a
        ld h,2
        ld (CB_SY),hl
        add a,96
        ld l,a
        ld h,3
        ld (CB_DY),hl
        ld hl,1
        ld (CB_NY),hl
        ld a,0xD0
        ld (CB_CMD),a
        jp vdpcmd

fillGrass:
        ld hl,(fS)
        ld de,128
        call max16
        ld (fS),hl
        ld hl,(fE)
        ld de,384
        call min16
        ld de,(fS)
        or a
        sbc hl,de
        ret c
        ret z
        ld (CB_NX),hl
        ex de,hl
        ld de,-128
        add hl,de
        ld (CB_DX),hl
        ld a,(rowR)
        add a,96
        ld l,a
        ld h,3
        ld (CB_DY),hl
        ld hl,1
        ld (CB_NY),hl
        ld a,(rowR)
        ld l,a
        ld h,0
        ld de,grassbTab
        add hl,de
        ld a,(hl)
        ld (CB_CLR),a
        ld a,0xC0
        ld (CB_CMD),a
        jp vdpcmd

; bring the back page's road up to date (copy changed bands from clean page 3)
syncPage:
        ld a,(bp)
        or a
        ld hl,pageDx0
        jr z,.p
        ld hl,pageDx1
.p:     ld (pdPtr),hl
        xor a
        ld (rowR),a
.band:  ld a,0xFF
        ld (bFirst),a
        ld hl,0xFFFF
        ld (bMin),hl
        ld hl,0
        ld (bMax),hl
        ld a,8
        ld (bCnt),a
.row:   ld a,(rowR)
        ld e,a
        ld d,0
        ld hl,dxb
        add hl,de
        ld c,(hl)
        ld hl,(pdPtr)
        add hl,de
        ld a,(hl)
        cp c
        jr z,.same
        ld b,a
        ld (hl),c
        call spanCalc
        ld hl,(X0)
        ld de,128
        call max16
        ld de,(bMin)
        call min16
        ld (bMin),hl
        ld hl,(X1)
        ld de,384
        call min16
        ld de,(bMax)
        call max16
        ld (bMax),hl
        ld a,(bFirst)
        cp 0xFF
        jr nz,.hf
        ld a,(rowR)
        ld (bFirst),a
.hf:    ld a,(rowR)
        ld (bLast),a
.same:  ld a,(rowR)
        inc a
        ld (rowR),a
        cp ROWS
        jr z,.flush
        ld hl,bCnt
        dec (hl)
        jr nz,.row
        call .flush
        jr .band
.flush: ld a,(bFirst)
        cp 0xFF
        ret z
        ld hl,(bMax)
        ld de,(bMin)
        or a
        sbc hl,de
        ret c
        ret z
        ld (CB_NX),hl
        ex de,hl
        ld de,-128
        add hl,de
        ld (CB_SX),hl
        ld (CB_DX),hl
        ld a,(bFirst)
        add a,96
        ld l,a
        ld h,3
        ld (CB_SY),hl
        ld a,(bp)
        ld h,a
        ld (CB_DY),hl
        ld a,(bLast)
        ld hl,bFirst
        sub (hl)
        inc a
        ld l,a
        ld h,0
        ld (CB_NY),hl
        ld a,0xD0
        ld (CB_CMD),a
        jp vdpcmd

;---------------------------------------------------------- objects
eraseObjs:
        ld a,(bp)
        or a
        ld hl,rects0
        jr z,.p
        ld hl,rects1
.p:     ld a,(hl)
        or a
        ret z
        ld b,a
        ld (hl),0
        inc hl
.l:     push bc
        ld a,(hl)
        ld (rX),a
        inc hl
        ld a,(hl)
        ld (rY),a
        inc hl
        ld a,(hl)
        ld (rNB),a
        inc hl
        ld a,(hl)
        ld (rNY),a
        inc hl
        push hl
        call eraseRect
        pop hl
        pop bc
        djnz .l
        ret

; erase rect (rX,rY,rNB,rNY) on back page from clean page 3; band lines are
; taken from the master backdrop with the current horizontal shift
eraseRect:
        ld a,(rY)
        ld b,a
        ld a,(rNY)
        add a,b
        ld c,a                  ; y1
        ; part A: [y0, min(y1,BAND_Y))
        ld a,c
        cp BAND_Y
        jr c,.a1
        ld a,BAND_Y
.a1:    ld (eY1),a
        ld a,b
        ld (eY0),a
        push bc
        call copyPlain
        pop bc
        ; part B: [max(y0,BAND_Y), min(y1,96))
        ld a,b
        cp BAND_Y
        jr nc,.b1
        ld a,BAND_Y
.b1:    ld (eY0),a
        ld a,c
        cp 96
        jr c,.b2
        ld a,96
.b2:    ld (eY1),a
        push bc
        call copyShift
        pop bc
        ; part C: [max(y0,96), y1)
        ld a,b
        cp 96
        jr nc,.c1
        ld a,96
.c1:    ld (eY0),a
        ld a,c
        ld (eY1),a
copyPlain:
        ld a,(eY0)
        ld b,a
        ld a,(eY1)
        sub b
        ret c
        ret z
        ld (CB_NY),a
        xor a
        ld (CB_NY+1),a
        ld a,(rX)
        ld (CB_SX),a
        ld (CB_DX),a
        xor a
        ld (CB_SX+1),a
        ld (CB_DX+1),a
        ld a,b
        ld (CB_SY),a
        ld (CB_DY),a
        ld a,3
        ld (CB_SY+1),a
        ld a,(bp)
        ld (CB_DY+1),a
        ld a,(rNB)
        ld l,a
        ld h,0
        add hl,hl
        ld (CB_NX),hl
        ld a,0xD0
        ld (CB_CMD),a
        jp vdpcmd

copyShift:
        ld a,(bandDone)
        or a
        ret nz
        ld a,(eY0)
        ld b,a
        ld a,(eY1)
        sub b
        ret c
        ret z
        ld (CB_NY),a
        xor a
        ld (CB_NY+1),a
        ld a,b
        ld (CB_SY),a
        ld (CB_DY),a
        ld a,3
        ld (CB_SY+1),a
        ld a,(bp)
        ld (CB_DY+1),a
        ld a,(rX)
        ld (CB_DX),a
        xor a
        ld (CB_DX+1),a
        ld (CB_SX+1),a
        ld a,(sNow)
        ld b,a
        ld a,(rX)
        add a,b                 ; source x (wraps at 256)
        ld (CB_SX),a
        ; first = min(w, 256 - sx)
        ld e,a
        ld d,0
        ld hl,256
        or a
        sbc hl,de               ; 256 - sx
        push hl
        ld a,(rNB)
        ld l,a
        ld h,0
        add hl,hl               ; w
        pop de
        push hl                 ; w
        call min16              ; hl = first
        ld (CB_NX),hl
        push hl
        ld a,0xD0
        ld (CB_CMD),a
        call vdpcmd
        pop de                  ; first
        pop hl                  ; w
        or a
        sbc hl,de
        ret z
        ret c
        ld (CB_NX),hl           ; rest
        ld hl,0
        ld (CB_SX),hl
        ld a,(rX)
        ld l,a
        ld h,0
        add hl,de
        ld (CB_DX),hl
        jp vdpcmd

; redraw the scrolling backdrop band on the back page if its shift changed
bandUpdate:
        xor a
        ld (bandDone),a
        ld a,(bp)
        ld hl,pageShift0
        or a
        jr z,.p
        inc hl
.p:     ld a,(sNow)
        cp (hl)
        ret z
        ld (hl),a
        ld a,1
        ld (bandDone),a
        ld a,(sNow)
        ld l,a
        ld h,0
        ld (CB_SX),hl
        ld hl,768+BAND_Y
        ld (CB_SY),hl
        ld hl,0
        ld (CB_DX),hl
        ld a,(bp)
        ld h,a
        ld l,BAND_Y
        ld (CB_DY),hl
        ld a,(sNow)
        ld e,a
        ld d,0
        ld hl,256
        or a
        sbc hl,de
        ld (CB_NX),hl
        ld hl,BAND_H
        ld (CB_NY),hl
        ld a,0xD0
        ld (CB_CMD),a
        call vdpcmd
        ld a,(sNow)
        or a
        ret z
        ld hl,0
        ld (CB_SX),hl
        ld e,a
        ld d,0
        ld hl,256
        or a
        sbc hl,de
        ld (CB_DX),hl
        ld (CB_NX),de
        jp vdpcmd

addRect:
        ld a,(bp)
        or a
        ld hl,rects0
        jr z,.p
        ld hl,rects1
.p:     ld a,(hl)
        cp MAXRECT
        ret nc
        inc (hl)
        add a,a
        add a,a
        inc a
        ld e,a
        ld d,0
        add hl,de
        ld a,(rX)
        ld (hl),a
        inc hl
        ld a,(rY)
        ld (hl),a
        inc hl
        ld a,(rNB)
        ld (hl),a
        inc hl
        ld a,(rNY)
        ld (hl),a
        ret

drawObjs:
        ld hl,(cz)
        ld de,ZNEAR
        add hl,de
        ex de,hl
        ld hl,(objStart)
.a:     ld c,(hl)
        inc hl
        ld b,(hl)
        dec hl
        push hl
        ld h,b
        ld l,c
        or a
        sbc hl,de
        pop hl
        jr nc,.ad
        inc hl
        inc hl
        inc hl
        inc hl
        jr .a
.ad:    ld (objStart),hl
        ld hl,(cz)
        ld de,ZFAR
        add hl,de
        ex de,hl
        ld hl,(objStart)
        ld b,0
.g:     ld a,b
        cp NOBJMAX
        jr nc,.gd
        ld a,(hl)
        inc hl
        push hl
        ld h,(hl)
        ld l,a
        or a
        sbc hl,de
        pop hl
        dec hl
        jr nc,.gd
        inc hl
        inc hl
        inc hl
        inc hl
        inc b
        jr .g
.gd:    ld a,(dState)
        cp 2
        ld a,0
        jr c,.dp
        inc a
.dp:    ld (dPend),a
        ld a,b
        or a
        jr z,.end
.d:     dec hl
        dec hl
        dec hl
        dec hl
        push hl
        push bc
        ld a,(dPend)
        or a
        jr z,.nd
        ld e,(hl)
        inc hl
        ld d,(hl)               ; object z
        ld hl,(dZ)
        or a
        sbc hl,de               ; dZ - z : drop farther -> draw it first
        jr c,.nd
        jr z,.nd
        call drawDrop
.nd:    pop bc
        pop hl
        push hl
        push bc
        call drawOne
        pop bc
        pop hl
        djnz .d
.end:   ld a,(dPend)
        or a
        ret z
        jp drawDrop

drawOne:
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (oZ),de
        ld a,(hl)
        ld (oT),a
        inc hl
        ld a,(hl)
        ld (oX),a
        ld hl,(cz)
        ex de,hl
        or a
        sbc hl,de
        ld (oD),hl
        ld a,(oT)
        cp T_STAR
        jr nz,.ns
        ld a,h
        or a
        jr nz,.chk
        ld a,l
        cp ZCAR+2
        ret c
.chk:   ld hl,(oZ)
        ld de,(coll1)
        or a
        sbc hl,de
        ret z
        ld hl,(oZ)
        ld de,(coll2)
        or a
        sbc hl,de
        ret z
        ld hl,(oD)
.ns:    srl h
        rr l
        srl h
        rr l
        ld de,rowofdTab
        add hl,de
        ld a,(hl)
        cp 255
        ret z
        ld (oR),a
        ld a,(oT)
        cp T_GATE
        jp nc,drawGate
        ld a,(oX)
        jp drawSpr

; A = x (signed) -> HL = 256 + dx(row) + x*w(row)/64   (biased screen x)
calcCenter:
        push af
        ld a,(oR)
        ld l,a
        ld h,0
        ld de,wTab
        add hl,de
        ld e,(hl)
        pop af
        call mulxw
        ld de,256
        add hl,de
        ld a,(oR)
        cp ROWS
        ret nc
        ld e,a
        ld d,0
        push hl
        ld hl,dxb
        add hl,de
        ld a,(hl)
        pop hl
        ld e,a
        rla
        sbc a,a
        ld d,a
        add hl,de
        ret

; A = x signed, E = w -> HL = (x*w)>>6 signed
mulxw:  ld d,0
        or a
        jp p,.pos
        neg
        call umul8
        call .sh
        xor a
        sub l
        ld l,a
        sbc a,a
        sub h
        ld h,a
        ret
.pos:   call umul8
.sh:    srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ret
umul8:  ld hl,0                 ; HL = A*E (D=0)
        ld b,8
.l:     add hl,hl
        rla
        jr nc,.n
        add hl,de
.n:     djnz .l
        ret

; draw object type (oT) at row (oR), lateral A
drawSpr:
        ld (oXs),a
        ld a,(oR)
        ld l,a
        ld h,0
        ld de,scaleTab
        add hl,de
        ld a,(hl)
        ld l,a
        ld a,(oT)
        cp T_DROP
        jr z,.drp
        add a,a
        add a,a
        add a,a
        add a,l
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        ld de,objInfo
        add hl,de
        ld a,2
        ld (oPage),a
        xor a
        ld (oLift),a
        jr .inf
.drp:   ld a,l                  ; drops are huge: three scale steps larger
        sub 3
        jr nc,.db
        xor a
.db:    ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        ld de,dropInfo
        add hl,de
        ld a,3
        ld (oPage),a
.inf:   ld a,(hl)
        ld (oSX),a
        inc hl
        ld a,(hl)
        ld (oSY),a
        inc hl
        ld a,(hl)
        ld (oW),a
        inc hl
        ld a,(hl)
        ld (oH),a
        ld a,(oXs)
        call calcCenter
        ld a,(oW)
        srl a
        ld e,a
        ld d,0
        or a
        sbc hl,de
        ld (oL),hl
        ld de,384
        or a
        sbc hl,de
        ret nc
        ld hl,(oL)
        ld a,(oW)
        ld e,a
        ld d,0
        add hl,de
        ld de,129
        or a
        sbc hl,de
        ret c
        ld a,(oR)
        add a,96
        ld hl,oLift
        sub (hl)
        ret c
        cp 24
        ret c
        ld (oBot),a
        sub 23                  ; visible rows below the HUD
        ld b,a
        ld a,(oH)
        cp b
        jr c,.full
        jr z,.full
        sub b
        ld c,a
        ld a,(oSY)
        add a,c
        ld (oSY),a
        ld a,b
        ld (oH),a
        ld a,24
        ld (oTop),a
        jr .tok
.full:  ld a,(oBot)
        ld hl,oH
        sub (hl)
        inc a
        ld (oTop),a
.tok:   ld a,(oBot)
        cp 212
        jr c,.bok
        sub 211
        ld b,a
        ld a,(oH)
        sub b
        ret c
        ret z
        ld (oH),a
.bok:   ld hl,(oL)
        ld de,128
        or a
        sbc hl,de
        jr nc,.lok
        ld a,l
        neg
        ld b,a
        ld a,(oSX)
        add a,b
        ld (oSX),a
        ld a,(oW)
        sub b
        ret z
        ret c
        ld (oW),a
        ld hl,128
        ld (oL),hl
.lok:   ld hl,(oL)
        ld a,(oW)
        ld e,a
        ld d,0
        add hl,de
        ld de,385
        or a
        sbc hl,de
        jr c,.rok
        ld hl,384
        ld de,(oL)
        or a
        sbc hl,de
        ld a,l
        ld (oW),a
        or a
        ret z
.rok:   ld a,(oSX)
        ld l,a
        ld h,0
        ld (CB_SX),hl
        ld a,(oSY)
        ld l,a
        ld a,(oPage)
        ld h,a
        ld (CB_SY),hl
        ld hl,(oL)
        ld de,-128
        add hl,de
        ld (CB_DX),hl
        ld a,l
        ld (oDX),a
        ld a,(oTop)
        ld l,a
        ld a,(bp)
        ld h,a
        ld (CB_DY),hl
        ld a,(oW)
        ld l,a
        ld h,0
        ld (CB_NX),hl
        ld a,(oH)
        ld l,a
        ld (CB_NY),hl
        ld a,0x98               ; LMMM, TIMP
        ld (CB_CMD),a
        call vdpcmd
        ld a,(oDX)
        and 0xFE
        ld (rX),a
        ld a,(oDX)
        ld e,a
        ld d,0
        ld a,(oW)
        ld l,a
        ld h,0
        add hl,de
        inc hl
        srl h
        rr l
        ld a,(rX)
        srl a
        ld e,a
        ld a,l
        sub e
        ld (rNB),a
        ld a,(oTop)
        ld (rY),a
        ld a,(oH)
        ld (rNY),a
        jp addRect

drawGate:
        ld a,(oT)
        ld (oGT),a
        ld a,T_POST
        ld (oT),a
        ld a,-72
        call drawSpr
        ld a,72
        call drawSpr
        ld a,(oR)               ; post height at this row
        ld l,a
        ld h,0
        ld de,scaleTab
        add hl,de
        ld a,(hl)
        add a,T_POST*8
        ld l,a
        ld h,0
        add hl,hl
        add hl,hl
        ld de,objInfo+3
        add hl,de
        ld b,(hl)
        ld a,(oR)
        add a,96
        sub b
        inc a
        ld (oTop),a
        ld a,b
        srl a
        srl a
        jr nz,.h1
        inc a
.h1:    ld c,a
        ld a,(oGT)
        cp T_FINISH
        jr nz,.h2
        sla c
.h2:    ld a,(oTop)
        add a,c
        jr c,.clip
        cp 213
        jr c,.hok
.clip:  ld a,212
        ld hl,oTop
        sub (hl)
        ret c
        ret z
        ld c,a
.hok:   ld a,c
        ld (rNY),a
        ld a,-72
        call calcCenter
        ld de,128
        call max16
        ld (gL),hl
        ld a,72
        call calcCenter
        ld de,384
        call min16
        ld (gR),hl
        ld de,(gL)
        or a
        sbc hl,de
        ret c
        ret z
        ld hl,(gL)
        ld de,-128
        add hl,de
        ld a,l
        and 0xFE
        ld (rX),a
        ld hl,(gR)
        ld de,-127
        add hl,de
        res 0,l                 ; x1 even (<=256)
        ld a,(rX)
        ld e,a
        ld d,0
        or a
        sbc hl,de
        ret c
        ret z
        ld (CB_NX),hl
        srl h
        rr l
        ld a,l
        ld (rNB),a
        ld a,(rX)
        ld (CB_DX),a
        xor a
        ld (CB_DX+1),a
        ld a,(oTop)
        ld (rY),a
        ld (CB_DY),a
        ld a,(bp)
        ld (CB_DY+1),a
        ld a,(rNY)
        ld (CB_NY),a
        xor a
        ld (CB_NY+1),a
        ld a,(oGT)
        cp T_FINISH
        ld a,0xCC
        jr nz,.col
        ld a,0x99
.col:   ld (CB_CLR),a
        ld a,0xC0
        ld (CB_CMD),a
        call vdpcmd
        jp addRect

;---------------------------------------------------------- things falling from the sky
; dState: 0 idle (waiting for dTimer), 1 uploading graphics, 2 falling, 3 landed
dropSchedule:
        call random
        ld l,a
        ld h,0
        add hl,hl
        push hl
        ld a,(course)
        add a,a
        ld e,a
        ld d,0
        ld hl,dropBase
        add hl,de
        ld e,(hl)
        inc hl
        ld d,(hl)
        pop hl
        add hl,de
        ld de,(vblTotal)
        add hl,de
        ld (dTimer),hl
        xor a
        ld (dState),a
        ret
dropBase: dw 450,350,250

random:         ; xorshift16 -> HL, A = H
        ld hl,(rnd)
        ld a,h
        rra
        ld a,l
        rra
        xor h
        ld h,a
        ld a,l
        rra
        ld a,h
        rra
        xor l
        ld l,a
        xor h
        ld h,a
        ld (rnd),hl
        ret

dropDist:       ; HL = dZ - cz (carry if behind)
        ld hl,(dZ)
        ld de,(cz)
        or a
        sbc hl,de
        ret

dropLogic:
        ld a,(lockCtl)
        or a
        ret nz
        ld a,(dState)
        or a
        jr z,.idle
        cp 1
        jp z,.load
        cp 2
        jp z,.fall
        ; ---- landed: obstacle on the track
        call dropDist
        jr c,.gone
        ld a,h
        or a
        ret nz
        ld a,(dPassed)
        or a
        jr nz,.chkg
        ld a,l
        cp ZCAR+1
        ret nc
        ld a,1
        ld (dPassed),a
        ld a,(dX)
        call distX
        cp DROP_HALF
        jr nc,.dodge
        ld a,(airborne)
        or a
        jr nz,.dodge
        jp doCrash
.dodge: ld a,0x03
        call addScore100
        ld a,MSG_DODGE
        call setMsg
        ld a,SFX_STAR
        jp sfxStart
.chkg:  ld a,l
        cp ZNEAR
        ret nc
.gone:  jp dropSchedule
.idle:  ld hl,(vblTotal)
        ld de,(dTimer)
        or a
        sbc hl,de
        ret m
        call random
.m10:   cp 10
        jr c,.ty
        sub 10
        jr .m10
.ty:    ld (dType),a
        xor a
        ld (dChunk),a
        ld a,1
        ld (dState),a
        ret
.load:  call uploadChunk
        call uploadChunk
        ld a,(dChunk)
        cp 11
        ret c
        ld hl,(cz)
        ld de,620
        add hl,de
        ld (dZ),hl
        call random
        and 0x7F
        cp 97
        jr c,.x1
        sub 32
.x1:    sub 48
        ld (dX),a
        ld a,160
        ld (dH),a
        ld hl,(vblTotal)
        ld (dLastV),hl
        xor a
        ld (dPassed),a
        ld a,2
        ld (dState),a
        ld a,(dType)
        add a,MSG_DROP0
        call setMsg
        ld a,SFX_FALL
        jp sfxStart
.fall:  ld hl,(vblTotal)
        ld de,(dLastV)
        ld (dLastV),hl
        or a
        sbc hl,de
        ld a,l
        add a,a
        add a,l
        ld b,a
        ld a,(dH)
        sub b
        jr c,.land
        jr z,.land
        ld (dH),a
        call dropDist
        jr c,.land
        ld a,h
        or a
        ret nz
        ld a,l
        cp 150
        ret nc
.land:  xor a
        ld (dH),a
        ld a,3
        ld (dState),a
        ld a,SFX_BOOM
        jp sfxStart

; stream 512 bytes of the chosen object's sheet into page 3 lines 212..255
uploadChunk:
        ld a,(dChunk)
        cp 11
        ret nc
        ld c,a
        add a,a
        add a,0xEA
        ld h,a
        ld l,0
        ld a,1
        call setVramW
        ld a,(dType)
        srl a
        add a,3
        ld (BANK2),a
        ld a,(dType)
        and 1
        ld hl,0x8000
        jr z,.e
        ld hl,0x8000+DROPSZ
.e:     ld a,c
        add a,a
        add a,h
        ld h,a
        ld c,2
.o:     ld b,0
.i:     ld a,(hl)
        out (VDP_DATA),a
        inc hl
        djnz .i
        dec c
        jr nz,.o
        ld a,1
        ld (BANK2),a
        ei
        ld hl,dChunk
        inc (hl)
        ret

drawDrop:
        xor a
        ld (dPend),a
        call dropDist
        ret c
        ld a,h
        cp 4
        ret nc
        or a
        jr nz,.far
        ld a,l
        cp ZNEAR
        ret c
.far:   srl h
        rr l
        srl h
        rr l
        ld de,rowofd2Tab
        add hl,de
        ld a,(hl)
        cp 255
        ret z
        ld (oR),a
        ld a,(dState)
        cp 2
        jr nz,.obj
        ld a,T_SHADOW
        ld (oT),a
        ld a,(dX)
        call drawSpr
.obj:   ld a,(oR)
        ld l,a
        ld h,0
        ld de,wTab
        add hl,de
        ld e,(hl)
        ld d,0
        ld a,(dH)
        call umul8
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld a,h
        or a
        ld a,l
        jr z,.lf
        ld a,255
.lf:    ld (oLift),a
        ld a,T_DROP
        ld (oT),a
        ld a,(dX)
        jp drawSpr

;---------------------------------------------------------- collisions
collisions:
        ld hl,(cz)
        ld de,ZCAR
        add hl,de
        ex de,hl
        ld hl,(objPass)
.l:     ld c,(hl)
        inc hl
        ld b,(hl)
        dec hl
        push hl
        ld h,b
        ld l,c
        or a
        sbc hl,de
        pop hl
        jr z,.hit
        jr nc,.done
.hit:   push hl
        push de
        call collide
        pop de
        pop hl
        inc hl
        inc hl
        inc hl
        inc hl
        jr .l
.done:  ld (objPass),hl
        ret

distX:  ; A = x -> A = |px - x|
        xor 0x80
        ld e,a
        ld a,(px)
        xor 0x80
        sub e
        ret nc
        neg
        ret

collide:
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld (oZ),de
        ld a,(hl)
        ld (oT),a
        inc hl
        ld b,(hl)
        cp T_GATE
        jr nc,.gate
        ld a,b
        call distX
        ld c,a
        ld a,(oT)
        cp T_TREE
        jr z,.tree
        cp T_SIGNL
        jr z,.tree
        cp T_SIGNR
        jr z,.tree
        cp T_ROCK
        jr z,.rock
        cp T_LOG
        jr z,.log
        cp T_STAR
        jr z,.star
        ret
.tree:  ld a,c
        cp 16
        ret nc
        jp doCrash
.rock:  ld a,(airborne)
        or a
        ret nz
        ld a,c
        cp 17
        ret nc
        jp doCrash
.log:   ld a,(airborne)
        or a
        ret nz
        ld a,c
        cp 28
        ret nc
        jp doJump
.star:  ld a,c
        cp 18
        ret nc
        ld hl,(coll1)
        ld (coll2),hl
        ld hl,(oZ)
        ld (coll1),hl
        ld a,0x05
        call addScore100
        ld a,SFX_STAR
        jp sfxStart
.gate:  ld a,(oT)
        cp T_FINISH
        jr z,.fin
        di
        ld a,(timeBCD)
        add a,0x20
        daa
        jr nc,.tc
        ld a,0x99
.tc:    ld (timeBCD),a
        ei
        ld hl,stage
        inc (hl)
        ld a,0x10
        call addScore100
        ld a,MSG_CHECK
        call setMsg
        ld a,SFX_GATE
        call sfxStart
        jr .posts
.fin:   ld a,1
        ld (finished),a
        ld a,0x50
        call addScore100
        ld a,SFX_GATE
        call sfxStart
.posts: ld a,72
        call distX
        cp 12
        jp c,doCrash
        ld a,-72
        call distX
        cp 12
        jp c,doCrash
        ret

doCrash:
        ld a,(crashT)
        or a
        ret nz
        di
        ld a,60
        ld (crashT),a
        ld hl,0
        ld (speed),hl
        ei
        ld a,SFX_CRASH
        jp sfxStart

doJump:
        ld a,(airOn)
        or a
        ret nz
        di
        ld hl,(speed)
        srl h
        rr l
        srl h
        rr l
        srl h
        rr l
        ld de,0x0180
        add hl,de
        ld (airV),hl
        ld hl,0x0100
        ld (airH),hl
        ld a,1
        ld (airOn),a
        ei
        ld a,0x01
        call addScore100
        ld a,SFX_JUMP
        jp sfxStart

;---------------------------------------------------------- HUD / text
drawHud:
        ld a,(bp)
        ld (drawPage),a
        ld hl,hud0
        or a
        jr z,.p
        ld hl,hud1
.p:     ld (hudPtr),hl
        ld de,score
        ld b,3
        call cmpCopy
        call nz,drawScore
        ld hl,(hudPtr)
        inc hl
        inc hl
        inc hl
        ld de,timeBCD
        ld b,1
        call cmpCopy
        call nz,drawTime
        ld hl,(hudPtr)
        ld de,4
        add hl,de
        ld de,stage
        ld b,1
        call cmpCopy
        call nz,drawStage
        ld hl,(hudPtr)
        ld de,5
        add hl,de
        ld de,msgId
        ld b,1
        call cmpCopy
        call nz,drawMsg
        ret

cmpCopy:        ; compare B bytes (DE) vs (HL); differ -> copy, NZ
        push hl
        push de
        push bc
.c:     ld a,(de)
        cp (hl)
        jr nz,.df
        inc hl
        inc de
        djnz .c
        pop bc
        pop de
        pop hl
        xor a
        ret
.df:    pop bc
        pop de
        pop hl
        ex de,hl
        ld c,b
        ld b,0
        ldir
        or 1
        ret

drawScore:
        ld de,56*256+4
        ld hl,score+2
        ld b,3
.l:     ld a,(hl)
        push hl
        push bc
        call drawBCD
        pop bc
        pop hl
        dec hl
        djnz .l
        ret

drawTime:
        ld de,160*256+4
        ld a,(timeBCD)
        jp drawBCD

drawStage:
        ld de,240*256+4
        ld a,(stage)
        add a,'0'
        jp drawChar

drawMsg:
        ld hl,msgBuf
        ld de,msgBuf+1
        ld bc,29
        ld (hl),' '
        ldir
        xor a
        ld (msgBuf+30),a
        ld a,(msgId)
        add a,a
        ld l,a
        ld h,0
        ld de,msgTab
        add hl,de
        ld a,(hl)
        inc hl
        ld h,(hl)
        ld l,a
        push hl
        ld b,0
.ln:    ld a,(hl)
        or a
        jr z,.lg
        inc hl
        inc b
        jr .ln
.lg:    pop hl
        ld a,b
        or a
        jr z,.dr
        ld a,30
        sub b
        srl a
        ld e,a
        ld d,0
        push hl
        ld hl,msgBuf
        add hl,de
        ex de,hl
        pop hl
        ld c,b
        ld b,0
        ldir
.dr:    ld hl,msgBuf
        ld de,8*256+14
        jp drawText

drawBCD:        ; A = bcd, D = x, E = y ; D += 16
        push af
        rrca
        rrca
        rrca
        rrca
        and 15
        add a,'0'
        call drawChar
        ld a,d
        add a,8
        ld d,a
        pop af
        and 15
        add a,'0'
        call drawChar
        ld a,d
        add a,8
        ld d,a
        ret

drawText:       ; HL = string, D = x, E = y
.l:     ld a,(hl)
        or a
        ret z
        push hl
        call drawChar
        pop hl
        inc hl
        ld a,d
        add a,8
        ld d,a
        jr .l

drawChar:       ; A = ascii, D = x, E = y ; preserves DE
        sub 32
        ld c,a
        ld b,0
        ld hl,fontMap
        add hl,bc
        ld a,(hl)
        ld l,a
        and 31
        add a,a
        add a,a
        add a,a
        ld (CB_SX),a
        xor a
        ld (CB_SX+1),a
        ld a,l
        rlca
        rlca
        rlca
        and 7
        add a,a
        add a,a
        add a,a
        add a,FONT_Y
        ld (CB_SY),a
        ld a,2
        ld (CB_SY+1),a
        ld a,d
        ld (CB_DX),a
        xor a
        ld (CB_DX+1),a
        ld a,e
        ld (CB_DY),a
        ld a,(drawPage)
        ld (CB_DY+1),a
        ld hl,8
        ld (CB_NX),hl
        ld (CB_NY),hl
        ld a,0xD0
        ld (CB_CMD),a
        jp vdpcmd

msgTab: dw mNone,mReady,mGo,mCheck,mTimeUp,mOver,mClear,mBonus,mC1,mC2,mC3,mDodge
        dw mD0,mD1,mD2,mD3,mD4,mD5,mD6,mD7,mD8,mD9
mNone:  db 0
mReady: db "GET READY",0
mGo:    db "GO!",0
mCheck: db "CHECKPOINT  +20 SEC",0
mTimeUp: db "TIME UP",0
mOver:  db "GAME OVER",0
mClear: db "COURSE CLEAR!",0
mBonus: db "TIME BONUS",0
mC1:    db "COURSE 1 - MEADOW",0
mC2:    db "COURSE 2 - DESERT",0
mC3:    db "COURSE 3 - TUNDRA",0
mDodge: db "DODGED!  +300",0
mD0:    db "LOOK OUT! UFO INCOMING!",0
mD1:    db "LOOK OUT! FALLING ROCKET!",0
mD2:    db "LOOK OUT! METEORITE!",0
mD3:    db "LOOK OUT! JUMBO JET!",0
mD4:    db "LOOK OUT! A DRAGON!",0
mD5:    db "LOOK OUT! SATELLITE!",0
mD6:    db "LOOK OUT! FLYING E-CAR!",0
mD7:    db "LOOK OUT! GIANT PHONE!",0
mD8:    db "LOOK OUT! FALLING COMPUTER!",0
mD9:    db "LOOK OUT! GRAND PIANO!",0

;---------------------------------------------------------- tables (bank 0)
courseTab:
        dw c0seg, c0obj, c0pal, c0ld
        dw c1seg, c1obj, c1pal, c1ld
        dw c2seg, c2obj, c2pal, c2ld

fontMap:   INCBIN "build/fontmap.bin"
objInfo:   INCBIN "build/objinfo.bin"
wTab:      INCBIN "build/wtab.bin"
extTab:    INCBIN "build/ext.bin"
grassbTab: INCBIN "build/grassb.bin"
scaleTab:  INCBIN "build/scale.bin"
rowofdTab: INCBIN "build/rowofd.bin"
rowofd2Tab: INCBIN "build/rowofd2.bin"
dropInfo:  INCBIN "build/dropinfo.bin"
sprCol:    INCBIN "build/spr_col.bin"

fPtrs:
Q = 0
        DUP 32
        dw ftab + Q*ROWS
Q = Q + 1
        EDUP

bank0End:
        ASSERT bank0End <= 0x8000
        BLOCK 0x8000-$, 0xFF

;=====================================================================
; BANK 1 (mapped at 0x8000 during play): curve table + courses
;=====================================================================
        ORG 0x8000
ftab:   INCBIN "build/ftab.bin"
c0seg:  INCBIN "build/c0_seg.bin"
c0obj:  INCBIN "build/c0_obj.bin"
c0pal:  INCBIN "build/c0_pal.bin"
c0ld:   INCBIN "build/c0_ld.bin"
c1seg:  INCBIN "build/c1_seg.bin"
c1obj:  INCBIN "build/c1_obj.bin"
c1pal:  INCBIN "build/c1_pal.bin"
c1ld:   INCBIN "build/c1_ld.bin"
c2seg:  INCBIN "build/c2_seg.bin"
c2obj:  INCBIN "build/c2_obj.bin"
c2pal:  INCBIN "build/c2_pal.bin"
c2ld:   INCBIN "build/c2_ld.bin"
bank1End:
        ASSERT bank1End <= 0xC000
        BLOCK 0xC000-$, 0xFF

;=====================================================================
; BANK 2 : graphics loaded into VRAM at boot / title
;=====================================================================
        ORG 0x8000
gRoad:   INCBIN "build/road.rle"
gSheet:  INCBIN "build/sheet.rle"
gSky:    INCBIN "build/sky.rle"
gTitle:  INCBIN "build/title.rle"
gSprPat: INCBIN "build/spr_pat.bin"
gShCol:  INCBIN "build/spr_shcol.bin"
bank2End:
        ASSERT bank2End <= 0xC000
        BLOCK 0xC000-$, 0xFF

;=====================================================================
; BANKS 3..7 : falling-object sheets (256x44, 4bpp = 5632 bytes each)
;=====================================================================
DROPSZ equ 5632
        ORG 0x8000
        INCBIN "build/drop0.bin"
        INCBIN "build/drop1.bin"
        BLOCK 0xC000-$, 0xFF
        ORG 0x8000
        INCBIN "build/drop2.bin"
        INCBIN "build/drop3.bin"
        BLOCK 0xC000-$, 0xFF
        ORG 0x8000
        INCBIN "build/drop4.bin"
        INCBIN "build/drop5.bin"
        BLOCK 0xC000-$, 0xFF
        ORG 0x8000
        INCBIN "build/drop6.bin"
        INCBIN "build/drop7.bin"
        BLOCK 0xC000-$, 0xFF
        ORG 0x8000
        INCBIN "build/drop8.bin"
        INCBIN "build/drop9.bin"
        BLOCK 0xC000-$, 0xFF
